# HP DMT Special Deals Platform - Login PoC with Mock GraphQL Server

## Install and run

- You will need Node.js (v14 or newer) and NPM installed.

### Server

- In the `server` directory, run `npm install`
- Run `npm start` to start the server

### Client

- In the `client` directory, run `npm install`
- Run `npm start` to start the server
- Go to http://localhost:3000 in your web browser

## Verification

### Successful login

- Enter `user1@dummy.com` in the email field
- Click the Login button
- You should be redirected to the landing page with option links

### Unsuccessful login

- Go back to the `/login` page
- Enter `users@dummy.com` in the email field
- Click the Login button
- You should be redirected to the landing page with an error message

## Notes

- The GraphQL endpoint can be set in the `client/.env` file or the `REACT_APP_GRAPHQL_URI` environment variable
- You can run `npm run gen` to generate TypeScript types from the GraphQL schema
- Run `npm run lint` in either directory to run ESLint
- The GraphQL resolver currently loads data from a static JSON file, but this can be [changed](https://www.apollographql.com/docs/apollo-server/data/data-sources/) to load from a database when needed
