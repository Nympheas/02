import { gql } from '@apollo/client'

interface AuthProfileMatrix {
  authProfileCd?: string
  regionCd?: string
  subRegion?: string
  countryCd?: string
  busModelCd?: string
  mCChargeCd?: string
  busGroupCd?: string
  busUnitcd?: string
  prodLineCd?: string
  prodFamCode?: string
  dealTypeCd?: number
  maxApprovalPct?: number
  minMarginApprovalPct?: number
  authMarginFL?: string
  pLSummaryAuth?: string
  maxLineUsdAmt?: number
  creationDts?: string
  updateDts?: string
  lastChangeEmpNR?: number
}

interface GuidenceRole {
  guidanceRoleId?: number
  guidanceRoleDesc?: string
  activeFL?: string
  defaultBenchMarkFL?: string
  allowGBAPNBD?: string
  authBenchmarkFL?: string
  authAdjustmentPCT?: number
  showExpertFL?: string
  showTypicalFL?: string
  showFloorFL?: string
  creationDTS?: string
  updateDTS?: string
  lastChangeEmpNR?: number
  primaryRole?: string
  showMaxApprovalFL?: string
  showPartialColorFL?: string
  showGuidanceDetailsFL?: string
  negativeMarginAprvlFL?: string
  showPricingBandFL?: string
  guidanceAuthProfileCD?: string
  showExcludeInheritPQBFL?: string
  approveExcludePQBFL?: string
  approveInheritPQBFL?: string
  allowGBAPLPFFL?: string
  showGuidancePLPFFL?: string
}

interface SecurityProfile {
  userEmail?: string
  isDealManagerAccess?: boolean
  message?: string
  guidenceRole?: GuidenceRole
  securityProfile?: [SecurityProfiles]
  authProfileMatrix?: [AuthProfileMatrix]
  userProfile?: UserProfile
}

interface SecurityProfiles {
  profileCd?: string
  dealStatus?: string
  actionDesc?: string
  actionId?: number
  actionValue?: string
  readOnlyProfileCD?: string
}

interface UserProfile {
  empId?: number
  userId?: string
  primaryRole?: string
  profileCd?: string
  authProfileCd?: string
  enabled?: string
  lastLogin?: string
  accessDartCost?: string
  restrictBDM?: string
  aSMProfile?: string
  accessCost?: string
  editSRWinLoss?: string
  primaryRegion?: string
  sROpenAllDeals?: string
  sREditAllDeals?: string
  asapRole?: string
  tenantId?: string
  tenantIdDealOverrideFlag?: string
  federalAccessFlag?: string
}

interface UserSecurityProfile {
  didError?: boolean
  errorCode?: string
  errorMessage?: string
  securityProfile?: SecurityProfile
}

export interface GetUserProfileResult {
  userSecurityProfile?: UserSecurityProfile
}

export interface GetUserProfileArgs {
  email: String
}

const GET_USER_PROFILE_QUERY = gql`
  query getuserprofile($email: String!) {
    userSecurityProfile(email: $email) {
      didError
      errorCode
      errorMessage
      securityProfile {
        userEmail
        isDealManagerAccess
        message
        userProfile {
          empId
          userId
          primaryRole
          profileCd
          authProfileCd
          enabled
          lastLogin
          accessDartCost
          restrictBDM
          aSMProfile
          accessCost
          editSRWinLoss
          primaryRegion
          sROpenAllDeals
          sREditAllDeals
          asapRole
          tenantId
          tenantIdDealOverrideFlag
          federalAccessFlag
        }

        authProfileMatrix {
          authProfileCd
          regionCd
          subRegion
          countryCd
          busModelCd
          mCChargeCd
          busGroupCd
          busUnitcd
          prodLineCd
          prodFamCode
          dealTypeCd
          maxApprovalPct
          minMarginApprovalPct
          authMarginFL
          pLSummaryAuth
          maxLineUsdAmt
          creationDts
          updateDts
          lastChangeEmpNR
        }
        securityProfile {
          profileCd
          dealStatus
          actionDesc
          actionId
          actionValue
          readOnlyProfileCD
        }
        guidenceRole {
          guidanceRoleId
          guidanceRoleDesc
          activeFL
          defaultBenchMarkFL
          allowGBAPNBD
          authBenchmarkFL
          authAdjustmentPCT
          showExpertFL
          showTypicalFL
          showFloorFL
          creationDTS
          updateDTS
          lastChangeEmpNR
          primaryRole
          showMaxApprovalFL
          showPartialColorFL
          showGuidanceDetailsFL
          negativeMarginAprvlFL
          showPricingBandFL
          guidanceAuthProfileCD
          showExcludeInheritPQBFL
          approveExcludePQBFL
          approveInheritPQBFL
          allowGBAPLPFFL
          showGuidancePLPFFL
        }
      }
    }
  }
`
export default GET_USER_PROFILE_QUERY
