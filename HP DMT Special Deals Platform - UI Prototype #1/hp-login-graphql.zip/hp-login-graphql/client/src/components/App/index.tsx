import './styles.css'

import CssBaseline from '@material-ui/core/CssBaseline'
import Grid from '@material-ui/core/Grid'
import InfoIcon from '@material-ui/icons/Info'
import Paper from '@material-ui/core/Paper'
import React, { useState } from 'react'
import { BrowserRouter as Router, Redirect, Route, Switch } from 'react-router-dom'

import Landing from '../Landing';
import LoginForm from '../LoginForm';

const App = () => {
  const [hasAccess, setHasAccess] = useState<boolean>(false)

  return (
    <Grid container component="main" className="main-container">
      <CssBaseline />
      <Grid item xs={6} component={Paper} square>
        <div className="info-icon">
          <InfoIcon />
        </div>
        <div className="content">
          <Router>
            <Switch>
              <Route path="/login">
                <LoginForm setHasAccess={setHasAccess} />
              </Route>
              <Route path="/landing">
                <Landing hasAccess={hasAccess} />
              </Route>
              <Route>
                <Redirect to="/login" />
              </Route>
            </Switch>
          </Router>
        </div>
      </Grid>
      <Grid item xs={6} className="splash-image" />
    </Grid>
  );
}
export default App
