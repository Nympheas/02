import './styles.css'

import Button from '@material-ui/core/Button'
import CircularProgress from '@material-ui/core/CircularProgress';
import TextField from '@material-ui/core/TextField'
import Typography from '@material-ui/core/Typography'
import React, { useEffect, useState } from 'react'
import { useHistory } from 'react-router-dom'
import { useLazyQuery } from '@apollo/client';

import GET_USER_PROFILE_QUERY, { GetUserProfileArgs, GetUserProfileResult } from '../../queries/get-user-profile'

interface LoginFormProps {
  setHasAccess: React.Dispatch<React.SetStateAction<boolean>>
}

const LoginForm: React.FC<LoginFormProps> = ({ setHasAccess }: LoginFormProps) => {
  const [email, setEmail] = useState<string>('')
  const history = useHistory()
  const [getUserProfile, { loading, data }] = useLazyQuery<GetUserProfileResult, GetUserProfileArgs>(GET_USER_PROFILE_QUERY)


  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setHasAccess(false)

    // Execute GraphQL query
    getUserProfile({ variables: { email } })
  }

  // Runs when data is populated with query result
  useEffect(() => {
    if (data) {
      // Check if user has access
      if (data?.userSecurityProfile?.securityProfile?.isDealManagerAccess) {
        setHasAccess(true)
      }

      // Redirect to landing page
      history.push('/landing')
    }
  }, [data, setHasAccess, history])

  return (
    <div className="login-form">
      <Typography component="h1" variant="h6" className="login-title">
        Login
      </Typography>
      <form onSubmit={handleLogin}>
        <TextField
          variant="outlined"
          margin="normal"
          required
          fullWidth
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          label="Email Address"
          autoComplete="email"
          autoFocus
        />
        <Button
          type="submit"
          fullWidth
          variant="contained"
          color="primary"
          disabled={loading}
        >
          {loading ? <CircularProgress size={24} /> : 'Login'}
        </Button>
      </form>
    </div >
  )
}
export default LoginForm
