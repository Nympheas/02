import './styles.css';

import Accordion from '@material-ui/core/Accordion'
import AccordionDetails from '@material-ui/core/Accordion'
import AccordionSummary from '@material-ui/core/AccordionSummary'
import Alert from '@material-ui/lab/Alert';
import CreateNewFolderIcon from '@material-ui/icons/CreateNewFolder'
import ExpandMoreIcon from '@material-ui/icons/ExpandMore'
import List from '@material-ui/core/List'
import ListItem from '@material-ui/core/ListItem'
import ListItemIcon from '@material-ui/core/ListItemIcon'
import ListItemText from '@material-ui/core/ListItemText'
import React from 'react'
import SearchIcon from '@material-ui/icons/Search'
import Typography from '@material-ui/core/Typography'

interface LandingProps {
  hasAccess: boolean
}

const Landing: React.FC<LandingProps> = ({ hasAccess }: LandingProps) => {
  return (
    <div className="landing-page">
      <Typography component="h1" variant="h6" className="welcome-text">
        Welcome back, John
      </Typography>
      {hasAccess ?
        <Accordion className="application-list" defaultExpanded classes={{ expanded: 'expanded' }}>
          <AccordionSummary
            expandIcon={<ExpandMoreIcon color="primary" />}
            classes={{ content: 'list-summary' }}
          >
            <Typography>Deal Manager</Typography>
            <Typography className="list-caption">Insert Caption here</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <List>
              <ListItem button>
                <ListItemIcon>
                  <CreateNewFolderIcon color="primary" />
                </ListItemIcon>
                <ListItemText>
                  New Deal
              </ListItemText>
              </ListItem>
              <ListItem button>
                <ListItemIcon>
                  <SearchIcon color="primary" />
                </ListItemIcon>
                <ListItemText>
                  Open Deal
              </ListItemText>
              </ListItem>
            </List>
          </AccordionDetails>
        </Accordion>
        : <Alert severity="warning">You do not have access to Deal Manager</Alert>}
    </div>
  )
}
export default Landing
