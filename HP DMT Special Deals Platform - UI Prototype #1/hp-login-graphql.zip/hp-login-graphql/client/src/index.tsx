import CssBaseline from '@material-ui/core/CssBaseline'
import ReactDOM from 'react-dom'
import { ApolloClient, InMemoryCache } from '@apollo/client';
import { ApolloProvider } from '@apollo/client/react';
import { ThemeProvider } from '@material-ui/core/styles'
import { createMuiTheme } from '@material-ui/core/styles'

import App from './components/App';

const theme = createMuiTheme({
  typography: {
    fontFamily: [
      'HP Simplified',
      'Arial',
      'sans-serif',
    ].join(',')
  },
  palette: {
    primary: {
      main: '#0096d6'
    }
  }
});

const client = new ApolloClient({
  uri: process.env.REACT_APP_GRAPHQL_URI,
  cache: new InMemoryCache()
});

ReactDOM.render(
  <ApolloProvider client={client}>
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <App />
    </ThemeProvider>
  </ApolloProvider>,
  document.getElementById('root')
);
