import { gql } from 'apollo-server'

const typeDefs = gql`
  type GuidenceRole {
    guidanceRoleId: Int
    guidanceRoleDesc: String
    activeFL: String
    defaultBenchMarkFL: String
    allowGBAPNBD: String
    authBenchmarkFL: String
    authAdjustmentPCT: Int
    showExpertFL: String
    showTypicalFL: String
    showFloorFL: String
    creationDTS: String
    updateDTS: String
    lastChangeEmpNR: Int
    primaryRole: String
    showMaxApprovalFL: String
    showPartialColorFL: String
    showGuidanceDetailsFL: String
    negativeMarginAprvlFL: String
    showPricingBandFL: String
    guidanceAuthProfileCD: String
    showExcludeInheritPQBFL: String
    approveExcludePQBFL: String
    approveInheritPQBFL: String
    allowGBAPLPFFL: String
    showGuidancePLPFFL: String
  }

  type SecurityProfiles {
    profileCd: String
    dealStatus: String
    actionDesc: String
    actionId: Int
    actionValue: String
    readOnlyProfileCD: String
  }

  type AuthProfileMatrix {
    authProfileCd: String
    regionCd: String
    subRegion: String
    countryCd: String
    busModelCd: String
    mCChargeCd: String
    busGroupCd: String
    busUnitcd: String
    prodLineCd: String
    prodFamCode: String
    dealTypeCd: Int
    maxApprovalPct: Int
    minMarginApprovalPct: Int
    authMarginFL: String
    pLSummaryAuth: String
    maxLineUsdAmt: Int
    creationDts: String
    updateDts: String
    lastChangeEmpNR: Int
  }

  type UserProfile {
    empId: Int
    userId: String
    primaryRole: String
    profileCd: String
    authProfileCd: String
    enabled: String
    lastLogin: String
    accessDartCost: String
    restrictBDM: String
    aSMProfile: String
    accessCost: String
    editSRWinLoss: String
    primaryRegion: String
    sROpenAllDeals: String
    sREditAllDeals: String
    asapRole: String
    tenantId: String
    tenantIdDealOverrideFlag: String
    federalAccessFlag: String
  }

  type SecurityProfile {
    userEmail: String
    isDealManagerAccess: Boolean
    message: String
    guidenceRole: GuidenceRole
    securityProfile: [SecurityProfiles]
    authProfileMatrix: [AuthProfileMatrix]
    userProfile: UserProfile
  }

  type UserSecurityProfile {
    didError: Boolean
    errorCode: String
    errorMessage: String
    securityProfile: SecurityProfile
  }

  type Query {
    userSecurityProfile(email: String!): UserSecurityProfile
  }
`

export default typeDefs
