import { readFile } from 'fs/promises'

import { Resolvers } from './generated/graphql'

const getData = async () => {
  // Load JSON data from file
  const data = await readFile('data/data.json', 'utf8')
  return JSON.parse(data)
}

const resolvers: Resolvers = {
  Query: {
    userSecurityProfile: async (parent: unknown, { email }) => {
      // Select specified user from data
      const users = await getData()
      return users[email]
    },
  },
}

export default resolvers
