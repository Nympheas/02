import { GraphQLResolveInfo } from 'graphql';
export type Maybe<T> = T | null;
export type Exact<T extends { [key: string]: unknown }> = { [K in keyof T]: T[K] };
export type MakeOptional<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]?: Maybe<T[SubKey]> };
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]: Maybe<T[SubKey]> };
export type RequireFields<T, K extends keyof T> = { [X in Exclude<keyof T, K>]?: T[X] } & { [P in K]-?: NonNullable<T[P]> };
/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
  ID: string;
  String: string;
  Boolean: boolean;
  Int: number;
  Float: number;
};

export type AuthProfileMatrix = {
  __typename?: 'AuthProfileMatrix';
  authProfileCd?: Maybe<Scalars['String']>;
  regionCd?: Maybe<Scalars['String']>;
  subRegion?: Maybe<Scalars['String']>;
  countryCd?: Maybe<Scalars['String']>;
  busModelCd?: Maybe<Scalars['String']>;
  mCChargeCd?: Maybe<Scalars['String']>;
  busGroupCd?: Maybe<Scalars['String']>;
  busUnitcd?: Maybe<Scalars['String']>;
  prodLineCd?: Maybe<Scalars['String']>;
  prodFamCode?: Maybe<Scalars['String']>;
  dealTypeCd?: Maybe<Scalars['Int']>;
  maxApprovalPct?: Maybe<Scalars['Int']>;
  minMarginApprovalPct?: Maybe<Scalars['Int']>;
  authMarginFL?: Maybe<Scalars['String']>;
  pLSummaryAuth?: Maybe<Scalars['String']>;
  maxLineUsdAmt?: Maybe<Scalars['Int']>;
  creationDts?: Maybe<Scalars['String']>;
  updateDts?: Maybe<Scalars['String']>;
  lastChangeEmpNR?: Maybe<Scalars['Int']>;
};

export type GuidenceRole = {
  __typename?: 'GuidenceRole';
  guidanceRoleId?: Maybe<Scalars['Int']>;
  guidanceRoleDesc?: Maybe<Scalars['String']>;
  activeFL?: Maybe<Scalars['String']>;
  defaultBenchMarkFL?: Maybe<Scalars['String']>;
  allowGBAPNBD?: Maybe<Scalars['String']>;
  authBenchmarkFL?: Maybe<Scalars['String']>;
  authAdjustmentPCT?: Maybe<Scalars['Int']>;
  showExpertFL?: Maybe<Scalars['String']>;
  showTypicalFL?: Maybe<Scalars['String']>;
  showFloorFL?: Maybe<Scalars['String']>;
  creationDTS?: Maybe<Scalars['String']>;
  updateDTS?: Maybe<Scalars['String']>;
  lastChangeEmpNR?: Maybe<Scalars['Int']>;
  primaryRole?: Maybe<Scalars['String']>;
  showMaxApprovalFL?: Maybe<Scalars['String']>;
  showPartialColorFL?: Maybe<Scalars['String']>;
  showGuidanceDetailsFL?: Maybe<Scalars['String']>;
  negativeMarginAprvlFL?: Maybe<Scalars['String']>;
  showPricingBandFL?: Maybe<Scalars['String']>;
  guidanceAuthProfileCD?: Maybe<Scalars['String']>;
  showExcludeInheritPQBFL?: Maybe<Scalars['String']>;
  approveExcludePQBFL?: Maybe<Scalars['String']>;
  approveInheritPQBFL?: Maybe<Scalars['String']>;
  allowGBAPLPFFL?: Maybe<Scalars['String']>;
  showGuidancePLPFFL?: Maybe<Scalars['String']>;
};

export type Query = {
  __typename?: 'Query';
  userSecurityProfile?: Maybe<UserSecurityProfile>;
};


export type QueryUserSecurityProfileArgs = {
  email: Scalars['String'];
};

export type SecurityProfile = {
  __typename?: 'SecurityProfile';
  userEmail?: Maybe<Scalars['String']>;
  isDealManagerAccess?: Maybe<Scalars['Boolean']>;
  message?: Maybe<Scalars['String']>;
  guidenceRole?: Maybe<GuidenceRole>;
  securityProfile?: Maybe<Array<Maybe<SecurityProfiles>>>;
  authProfileMatrix?: Maybe<Array<Maybe<AuthProfileMatrix>>>;
  userProfile?: Maybe<UserProfile>;
};

export type SecurityProfiles = {
  __typename?: 'SecurityProfiles';
  profileCd?: Maybe<Scalars['String']>;
  dealStatus?: Maybe<Scalars['String']>;
  actionDesc?: Maybe<Scalars['String']>;
  actionId?: Maybe<Scalars['Int']>;
  actionValue?: Maybe<Scalars['String']>;
  readOnlyProfileCD?: Maybe<Scalars['String']>;
};

export type UserProfile = {
  __typename?: 'UserProfile';
  empId?: Maybe<Scalars['Int']>;
  userId?: Maybe<Scalars['String']>;
  primaryRole?: Maybe<Scalars['String']>;
  profileCd?: Maybe<Scalars['String']>;
  authProfileCd?: Maybe<Scalars['String']>;
  enabled?: Maybe<Scalars['String']>;
  lastLogin?: Maybe<Scalars['String']>;
  accessDartCost?: Maybe<Scalars['String']>;
  restrictBDM?: Maybe<Scalars['String']>;
  aSMProfile?: Maybe<Scalars['String']>;
  accessCost?: Maybe<Scalars['String']>;
  editSRWinLoss?: Maybe<Scalars['String']>;
  primaryRegion?: Maybe<Scalars['String']>;
  sROpenAllDeals?: Maybe<Scalars['String']>;
  sREditAllDeals?: Maybe<Scalars['String']>;
  asapRole?: Maybe<Scalars['String']>;
  tenantId?: Maybe<Scalars['String']>;
  tenantIdDealOverrideFlag?: Maybe<Scalars['String']>;
  federalAccessFlag?: Maybe<Scalars['String']>;
};

export type UserSecurityProfile = {
  __typename?: 'UserSecurityProfile';
  didError?: Maybe<Scalars['Boolean']>;
  errorCode?: Maybe<Scalars['String']>;
  errorMessage?: Maybe<Scalars['String']>;
  securityProfile?: Maybe<SecurityProfile>;
};



export type ResolverTypeWrapper<T> = Promise<T> | T;


export type LegacyStitchingResolver<TResult, TParent, TContext, TArgs> = {
  fragment: string;
  resolve: ResolverFn<TResult, TParent, TContext, TArgs>;
};

export type NewStitchingResolver<TResult, TParent, TContext, TArgs> = {
  selectionSet: string;
  resolve: ResolverFn<TResult, TParent, TContext, TArgs>;
};
export type StitchingResolver<TResult, TParent, TContext, TArgs> = LegacyStitchingResolver<TResult, TParent, TContext, TArgs> | NewStitchingResolver<TResult, TParent, TContext, TArgs>;
export type Resolver<TResult, TParent = {}, TContext = {}, TArgs = {}> =
  | ResolverFn<TResult, TParent, TContext, TArgs>
  | StitchingResolver<TResult, TParent, TContext, TArgs>;

export type ResolverFn<TResult, TParent, TContext, TArgs> = (
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => Promise<TResult> | TResult;

export type SubscriptionSubscribeFn<TResult, TParent, TContext, TArgs> = (
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => AsyncIterator<TResult> | Promise<AsyncIterator<TResult>>;

export type SubscriptionResolveFn<TResult, TParent, TContext, TArgs> = (
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => TResult | Promise<TResult>;

export interface SubscriptionSubscriberObject<TResult, TKey extends string, TParent, TContext, TArgs> {
  subscribe: SubscriptionSubscribeFn<{ [key in TKey]: TResult }, TParent, TContext, TArgs>;
  resolve?: SubscriptionResolveFn<TResult, { [key in TKey]: TResult }, TContext, TArgs>;
}

export interface SubscriptionResolverObject<TResult, TParent, TContext, TArgs> {
  subscribe: SubscriptionSubscribeFn<any, TParent, TContext, TArgs>;
  resolve: SubscriptionResolveFn<TResult, any, TContext, TArgs>;
}

export type SubscriptionObject<TResult, TKey extends string, TParent, TContext, TArgs> =
  | SubscriptionSubscriberObject<TResult, TKey, TParent, TContext, TArgs>
  | SubscriptionResolverObject<TResult, TParent, TContext, TArgs>;

export type SubscriptionResolver<TResult, TKey extends string, TParent = {}, TContext = {}, TArgs = {}> =
  | ((...args: any[]) => SubscriptionObject<TResult, TKey, TParent, TContext, TArgs>)
  | SubscriptionObject<TResult, TKey, TParent, TContext, TArgs>;

export type TypeResolveFn<TTypes, TParent = {}, TContext = {}> = (
  parent: TParent,
  context: TContext,
  info: GraphQLResolveInfo
) => Maybe<TTypes> | Promise<Maybe<TTypes>>;

export type IsTypeOfResolverFn<T = {}, TContext = {}> = (obj: T, context: TContext, info: GraphQLResolveInfo) => boolean | Promise<boolean>;

export type NextResolverFn<T> = () => Promise<T>;

export type DirectiveResolverFn<TResult = {}, TParent = {}, TContext = {}, TArgs = {}> = (
  next: NextResolverFn<TResult>,
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => TResult | Promise<TResult>;

/** Mapping between all available schema types and the resolvers types */
export type ResolversTypes = {
  AuthProfileMatrix: ResolverTypeWrapper<AuthProfileMatrix>;
  String: ResolverTypeWrapper<Scalars['String']>;
  Int: ResolverTypeWrapper<Scalars['Int']>;
  GuidenceRole: ResolverTypeWrapper<GuidenceRole>;
  Query: ResolverTypeWrapper<{}>;
  SecurityProfile: ResolverTypeWrapper<SecurityProfile>;
  Boolean: ResolverTypeWrapper<Scalars['Boolean']>;
  SecurityProfiles: ResolverTypeWrapper<SecurityProfiles>;
  UserProfile: ResolverTypeWrapper<UserProfile>;
  UserSecurityProfile: ResolverTypeWrapper<UserSecurityProfile>;
};

/** Mapping between all available schema types and the resolvers parents */
export type ResolversParentTypes = {
  AuthProfileMatrix: AuthProfileMatrix;
  String: Scalars['String'];
  Int: Scalars['Int'];
  GuidenceRole: GuidenceRole;
  Query: {};
  SecurityProfile: SecurityProfile;
  Boolean: Scalars['Boolean'];
  SecurityProfiles: SecurityProfiles;
  UserProfile: UserProfile;
  UserSecurityProfile: UserSecurityProfile;
};

export type AuthProfileMatrixResolvers<ContextType = any, ParentType extends ResolversParentTypes['AuthProfileMatrix'] = ResolversParentTypes['AuthProfileMatrix']> = {
  authProfileCd?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  regionCd?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  subRegion?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  countryCd?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  busModelCd?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  mCChargeCd?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  busGroupCd?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  busUnitcd?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  prodLineCd?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  prodFamCode?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  dealTypeCd?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  maxApprovalPct?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  minMarginApprovalPct?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  authMarginFL?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  pLSummaryAuth?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  maxLineUsdAmt?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  creationDts?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  updateDts?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  lastChangeEmpNR?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
};

export type GuidenceRoleResolvers<ContextType = any, ParentType extends ResolversParentTypes['GuidenceRole'] = ResolversParentTypes['GuidenceRole']> = {
  guidanceRoleId?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  guidanceRoleDesc?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  activeFL?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  defaultBenchMarkFL?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  allowGBAPNBD?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  authBenchmarkFL?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  authAdjustmentPCT?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  showExpertFL?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  showTypicalFL?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  showFloorFL?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  creationDTS?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  updateDTS?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  lastChangeEmpNR?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  primaryRole?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  showMaxApprovalFL?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  showPartialColorFL?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  showGuidanceDetailsFL?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  negativeMarginAprvlFL?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  showPricingBandFL?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  guidanceAuthProfileCD?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  showExcludeInheritPQBFL?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  approveExcludePQBFL?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  approveInheritPQBFL?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  allowGBAPLPFFL?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  showGuidancePLPFFL?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
};

export type QueryResolvers<ContextType = any, ParentType extends ResolversParentTypes['Query'] = ResolversParentTypes['Query']> = {
  userSecurityProfile?: Resolver<Maybe<ResolversTypes['UserSecurityProfile']>, ParentType, ContextType, RequireFields<QueryUserSecurityProfileArgs, 'email'>>;
};

export type SecurityProfileResolvers<ContextType = any, ParentType extends ResolversParentTypes['SecurityProfile'] = ResolversParentTypes['SecurityProfile']> = {
  userEmail?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  isDealManagerAccess?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  message?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  guidenceRole?: Resolver<Maybe<ResolversTypes['GuidenceRole']>, ParentType, ContextType>;
  securityProfile?: Resolver<Maybe<Array<Maybe<ResolversTypes['SecurityProfiles']>>>, ParentType, ContextType>;
  authProfileMatrix?: Resolver<Maybe<Array<Maybe<ResolversTypes['AuthProfileMatrix']>>>, ParentType, ContextType>;
  userProfile?: Resolver<Maybe<ResolversTypes['UserProfile']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
};

export type SecurityProfilesResolvers<ContextType = any, ParentType extends ResolversParentTypes['SecurityProfiles'] = ResolversParentTypes['SecurityProfiles']> = {
  profileCd?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  dealStatus?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  actionDesc?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  actionId?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  actionValue?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  readOnlyProfileCD?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
};

export type UserProfileResolvers<ContextType = any, ParentType extends ResolversParentTypes['UserProfile'] = ResolversParentTypes['UserProfile']> = {
  empId?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  userId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  primaryRole?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  profileCd?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  authProfileCd?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  enabled?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  lastLogin?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  accessDartCost?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  restrictBDM?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  aSMProfile?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  accessCost?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  editSRWinLoss?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  primaryRegion?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  sROpenAllDeals?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  sREditAllDeals?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  asapRole?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  tenantId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  tenantIdDealOverrideFlag?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  federalAccessFlag?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
};

export type UserSecurityProfileResolvers<ContextType = any, ParentType extends ResolversParentTypes['UserSecurityProfile'] = ResolversParentTypes['UserSecurityProfile']> = {
  didError?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  errorCode?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  errorMessage?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  securityProfile?: Resolver<Maybe<ResolversTypes['SecurityProfile']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
};

export type Resolvers<ContextType = any> = {
  AuthProfileMatrix?: AuthProfileMatrixResolvers<ContextType>;
  GuidenceRole?: GuidenceRoleResolvers<ContextType>;
  Query?: QueryResolvers<ContextType>;
  SecurityProfile?: SecurityProfileResolvers<ContextType>;
  SecurityProfiles?: SecurityProfilesResolvers<ContextType>;
  UserProfile?: UserProfileResolvers<ContextType>;
  UserSecurityProfile?: UserSecurityProfileResolvers<ContextType>;
};


/**
 * @deprecated
 * Use "Resolvers" root object instead. If you wish to get "IResolvers", add "typesPrefix: I" to your config.
 */
export type IResolvers<ContextType = any> = Resolvers<ContextType>;
