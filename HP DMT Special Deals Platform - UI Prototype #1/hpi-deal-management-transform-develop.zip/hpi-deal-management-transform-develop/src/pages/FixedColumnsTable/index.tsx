import React from "react";
import CommonTable from "../../components/CommonTable";
import { TableColumn } from "../../components/CommonTable/types";
import products from "../../data/products.json";

const defaultCols: TableColumn[] = [
  {
    key: "prodSearchId",
    label: "Product Search ID",
  },
  {
    key: "prodSearchDesc",
    label: "Product Search Description",
  },
  {
    key: "createdBy",
    label: "Created By",
  },
  {
    key: "name",
    label: "Name",
  },
  {
    key: "lastModBy",
    label: "Last Modified By",
  },
  {
    key: "lastModById",
    label: "Last Modified By ID",
  },
];

const FixedColumnsTable: React.FunctionComponent = () => {
  return (
    <CommonTable rowData={products} defaultColumns={defaultCols} fixedColumns />
  );
};

export default FixedColumnsTable;
