import { Flag } from "@material-ui/icons";
import { RowClassParams } from "ag-grid-community";
import React from "react";
import CommonTable from "../../components/CommonTable";
import { TableColumn } from "../../components/CommonTable/types";
import { getHeaderContextualMenuItems } from "../../components/CommonTable/utils/contextual-menu";
import products from "../../data/products.json";

import "./theme.scss";

const defaultCols: TableColumn[] = [
  {
    key: "prodSearchId",
    label: "Product Search ID",
    cellType: "number",
    editable: false,
    onDoubleClick: () => {
      // eslint-disable-next-line no-console
      console.log("open new window or pop-up");
    },
  },
  {
    key: "prodSearchDesc",
    label: "Product Search Description",
  },
  {
    key: "createdBy",
    label: "Created By",
    isCellEditingDisabled: (params) => params.data.createdById === 2230,
  },
  {
    key: "createdDate",
    label: "Created Date",
    cellType: "date",
  },
  {
    key: "name",
    label: "Name",
  },
  {
    key: "lastModBy",
    label: "Last Modified By",
  },
  {
    key: "productFlag",
    label: "Product Flag",
    toggleableStatus: {
      statusToggledKey: "productFlagEnabled",
      onStatusToggled: (newStatus, rowIndex) => {
        // eslint-disable-next-line no-console
        console.log(`status of row ${rowIndex} changed to ${newStatus}`);
      },
    },
  },
  {
    key: "lastModById",
    label: "Last Modified By ID",
    cellType: "number",
    isFormatValid: (value) =>
      /^[0-9]{1,10}$/.test(`${value}`) ? null : ["Only numbers are allowed"],
  },
  {
    key: "statusFg",
    label: "Status FG",
    cellType: "dropdown",
    dropdownOptions: ["A", "B", "C", "Disabled"],
    isCellEditingDisabled: (params) => params.value === "Disabled",
    customIcon: {
      getContent: ({ value }) => (
        <Flag color={value === "A" ? "primary" : "secondary"} />
      ),
      tooltipMessage: ({ value }) => value,
      onClick: () => {
        // Use this function to redirect the user or open a popup
        // eslint-disable-next-line no-console
        console.log("custom icon clicked");
        window.open("https://google.com", "_blank");
      },
    },
  },
];

const FullTable: React.FunctionComponent = () => {
  return (
    <CommonTable
      rowData={products}
      defaultColumns={defaultCols}
      getRowProperties={(data) => {
        return {
          bundleExpand:
            data.prodSearchId === 4044 ? (
              <span>Created By: {data.createdBy}</span>
            ) : null,
        };
      }}
      contextualMenuOptions={{
        getCellItems: (cell, actionMethods) =>
          cell.columnId === "prodSearchDesc"
            ? getHeaderContextualMenuItems({
                wrapText: actionMethods.wrapText,
              })
            : [],
      }}
      themeOptions={{
        getRowClass: (params: RowClassParams) => {
          const flagEnabled = params.data.productFlagEnabled;
          return flagEnabled ? "product-has-flag" : "";
        },
        getCellClass: (params) => {
          if (params.colId === "prodSearchId") {
            return `${params.value}` === "4068" ? "special-cell" : "";
          }
          return "";
        },
      }}
    />
  );
};

export default FullTable;
