import React from "react";
import { Switch, Route } from "react-router-dom";
import FixedColumnsTable from "../pages/FixedColumnsTable";
import NoFilterTable from "../pages/NoFilterTable";
import FullTable from "../pages/FullTable";

type AppRoute = {
  path: string;
  component: React.FunctionComponent;
};

const appRoutes: AppRoute[] = [
  {
    path: "/",
    component: FullTable,
  },
  {
    path: "/no-filters",
    component: NoFilterTable,
  },
  {
    path: "/fixed-columns",
    component: FixedColumnsTable,
  },
];

const routes = (
  <Switch>
    {appRoutes.map((route, index) => (
      <Route path={route.path} key={index} exact>
        {route.component}
      </Route>
    ))}
  </Switch>
);

export default routes;
