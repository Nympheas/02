import React, { useState } from "react";
import moment from "moment";
import { ICellRendererParams } from "ag-grid-community";
import DatePicker from "../../DatePicker";
import BaseCustomCell from "../BaseCustomCell";
import { CellSelectionProps, TableColumn } from "../../types";

export type CustomDateCellProps = {
  value: number;
  setValue: (newValue: number) => void;
  tableColumn: TableColumn;
} & CellSelectionProps &
  ICellRendererParams;

const CustomDateCell: React.FunctionComponent<CustomDateCellProps> = (
  props
) => {
  const {
    value,
    setValue,
    tableColumn,
    api,
    columnApi,
    data,
    rowIndex,
    onMouseDown,
    onClick,
  } = props;

  const [showEditor, setShowEditor] = useState<boolean>(false);
  const [selectedDate, setSelectedDate] = useState<Date | null>(
    moment(value).toDate()
  );

  return (
    <BaseCustomCell
      gridApi={api}
      columnApi={columnApi}
      onMouseDown={onMouseDown}
      onClick={onClick}
      rowIndex={rowIndex}
      data={data}
      tableColumn={tableColumn}
      disableTooltip={showEditor}
    >
      <div
        onDoubleClick={() => {
          setShowEditor(true);
        }}
      >
        {moment(value).format("MM/DD/YYYY - hh:mm A")}
        {showEditor && (
          <DatePicker
            selectedDate={selectedDate}
            onChange={(newDate) => {
              setSelectedDate(newDate);
              setValue(moment(newDate as Date).unix() * 1000);
            }}
            onClose={() => setShowEditor(false)}
          />
        )}
      </div>
    </BaseCustomCell>
  );
};

export default CustomDateCell;
