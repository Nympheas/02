/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */
import { Button, Tooltip } from "@material-ui/core";
import { ColumnApi, GridApi } from "ag-grid-community";
import moment from "moment";
import React, { useState } from "react";
import StatusCheckbox from "../../StatusCheckbox";
import { CellSelectionProps, TableColumn } from "../../types";
import "./styles.scss";

export type BaseCustomCellProps = {
  gridApi: GridApi;
  columnApi: ColumnApi;
  rowIndex: number;
  tableColumn: TableColumn;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  data: any;
  className?: string;
  onDoubleClick?: React.MouseEventHandler<HTMLDivElement>;
  disableTooltip?: boolean;
} & CellSelectionProps;

const BaseCustomCell: React.FunctionComponent<BaseCustomCellProps> = (
  props
) => {
  const {
    children,
    gridApi,
    columnApi,
    rowIndex,
    tableColumn,
    data,
    className,
    onDoubleClick,
    onMouseDown,
    disableTooltip,
  } = props;

  const {
    toggleableStatus,
    onDoubleClick: onColumnDoubleClick,
    customIcon,
  } = tableColumn;

  const [disableMainTooltip, setDisableMainTooltip] = useState<boolean>(false);

  const getFormattedValue = () => {
    let value = data ? data[tableColumn.key] : "";
    if (value !== "" && tableColumn.cellType === "date") {
      value = moment(value).format("MM/DD/YYYY - hh:mm A");
    }
    return `${value}`;
  };

  const renderCustomIcon = () => {
    if (!customIcon) {
      return <></>;
    }
    const params = {
      api: gridApi,
      columnApi,
      value: data[tableColumn.key],
      data,
    };
    const wrapper = (content: JSX.Element) => {
      const innerContent = (
        <div
          onClick={(event) => {
            event.preventDefault();
            event.preventDefault();
            if (customIcon.onClick) {
              customIcon.onClick(event);
            }
          }}
        >
          {content}
        </div>
      );
      if (customIcon.tooltipMessage) {
        return (
          <Tooltip
            PopperProps={{
              className:
                "MuiTooltip-popper MuiTooltip-popperInteractive custom-tooltip",
            }}
            enterDelay={1500}
            enterNextDelay={500}
            leaveDelay={10}
            title={<div>{customIcon.tooltipMessage(params)}</div>}
            interactive
            onOpen={() => setDisableMainTooltip(true)}
            onClose={() => setDisableMainTooltip(false)}
          >
            {innerContent}
          </Tooltip>
        );
      }
      return innerContent;
    };
    return wrapper(customIcon.getContent(params));
  };

  const cellContent = (
    <div
      className={`base-custom-cell${className ? ` ${className}` : ""}`}
      onDoubleClick={(event) => {
        if (onColumnDoubleClick) {
          event.stopPropagation();
          event.preventDefault();
          onColumnDoubleClick(event);
        } else if (onDoubleClick) {
          onDoubleClick(event);
        }
      }}
      onMouseDown={(event) => {
        if (event.target) {
          onMouseDown(event);
        }
      }}
    >
      {renderCustomIcon()}
      {toggleableStatus && (
        <StatusCheckbox
          checked={data[toggleableStatus.statusToggledKey]}
          onChange={(newChecked) =>
            toggleableStatus.onStatusToggled(
              newChecked,
              rowIndex,
              gridApi,
              columnApi
            )
          }
        />
      )}
      {children}
      <div
        className="fill-handle"
        onMouseDown={(event) => onMouseDown(event)}
      />
    </div>
  );

  return disableMainTooltip || disableTooltip ? (
    cellContent
  ) : (
    <Tooltip
      PopperProps={{
        className:
          "MuiTooltip-popper MuiTooltip-popperInteractive custom-tooltip",
      }}
      enterDelay={2000}
      enterNextDelay={500}
      leaveDelay={0}
      title={
        <div>
          <span className="label">{tableColumn.label}:</span>
          <span className="value">{getFormattedValue()}</span>
          <Button
            variant="contained"
            color="primary"
            onClick={(event) => {
              navigator.clipboard.writeText(getFormattedValue());
              const tooltipEl = (event.target as HTMLElement).closest(
                ".custom-tooltip"
              );
              if (tooltipEl) {
                (tooltipEl as HTMLElement).style.display = "none";
              }
            }}
          >
            Copy
          </Button>
        </div>
      }
      interactive
    >
      {cellContent}
    </Tooltip>
  );
};

export default BaseCustomCell;
