import React, { useState } from "react";
import { MenuItem, Select } from "@material-ui/core";
import { CellClassParams, ICellRendererParams } from "ag-grid-community";
import { CellSelectionProps, TableColumnWithDropdown } from "../../types";
import BaseCustomCell from "../BaseCustomCell";
import "./styles.scss";

export type CustomDropdownCellProps = {
  value: string;
  setValue: (newValue: string) => void;
  tableColumn: TableColumnWithDropdown;
} & CellSelectionProps &
  ICellRendererParams;

const CustomDropdownCell: React.FunctionComponent<CustomDropdownCellProps> = (
  props
) => {
  const { value, setValue, tableColumn } = props;
  const { dropdownOptions } = tableColumn;
  const {
    node,
    data,
    $scope,
    rowIndex,
    colDef,
    context,
    api,
    onMouseDown,
    onClick,
    columnApi,
  } = props;

  const [showEditor, setShowEditor] = useState<boolean>(false);
  const [selectedOption, setSelectedOption] = useState<string>(value);

  const editableFunc: ((params: CellClassParams) => boolean) | null =
    colDef.editable && typeof colDef.editable !== "boolean"
      ? (colDef.editable as (params: unknown) => boolean)
      : null;
  let isEditable = !!dropdownOptions;
  if (editableFunc) {
    isEditable =
      isEditable &&
      editableFunc({
        node,
        data,
        colDef,
        context,
        api,
        columnApi,
        value,
        rowIndex,
        $scope,
      });
  } else {
    isEditable = isEditable && colDef.editable !== false;
  }

  const staticContent = <>{value}</>;

  const editorContent = isEditable
    ? dropdownOptions && (
        <Select
          open
          value={selectedOption}
          onChange={(event) => {
            const newValue = event.target.value as string;
            setSelectedOption(newValue);
            setValue(newValue);
          }}
          onClose={() => {
            setShowEditor(false);
          }}
          MenuProps={{
            className: "custom-dropdown-menu",
          }}
        >
          {dropdownOptions.map((option, index) => (
            <MenuItem value={option} key={index}>
              {option}
            </MenuItem>
          ))}
        </Select>
      )
    : staticContent;

  return (
    <BaseCustomCell
      rowIndex={rowIndex}
      gridApi={api}
      columnApi={columnApi}
      onMouseDown={onMouseDown}
      onClick={onClick}
      data={data}
      tableColumn={tableColumn}
      onDoubleClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        setShowEditor(true);
      }}
      disableTooltip={showEditor}
    >
      <div className="custom-dropdown">
        {showEditor ? editorContent : staticContent}
      </div>
    </BaseCustomCell>
  );
};

export default CustomDropdownCell;
