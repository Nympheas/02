import React from "react";
import { ICellRendererParams } from "ag-grid-community";
import BaseCustomCell from "../BaseCustomCell";
import { CellSelectionProps, TableColumn } from "../../types";
import "./styles.scss";

export type CustomTextCellProps = {
  value: string | number;
  setValue: (newValue: string | number) => void;
  tableColumn: TableColumn;
} & CellSelectionProps &
  ICellRendererParams;

const CustomTextCell: React.FunctionComponent<CustomTextCellProps> = (
  props
) => {
  const {
    value,
    tableColumn,
    api,
    columnApi,
    onMouseDown,
    onClick,
    data,
    rowIndex,
    eGridCell,
  } = props;

  return (
    <BaseCustomCell
      className={`custom-cell-text${!tableColumn.wrapText ? " no-wrap" : ""}`}
      gridApi={api}
      columnApi={columnApi}
      onMouseDown={onMouseDown}
      onClick={onClick}
      rowIndex={rowIndex}
      data={data}
      tableColumn={tableColumn}
      disableTooltip={eGridCell.classList.contains("ag-cell-inline-editing")}
    >
      <span className={!tableColumn.wrapText ? "overflow-text" : ""}>
        {value}
      </span>
    </BaseCustomCell>
  );
};

export default CustomTextCell;
