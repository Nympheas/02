import { PopoverPosition } from "@material-ui/core";
import { GridApi } from "ag-grid-community";
import React from "react";
import { ContextualMenuItem } from "../../types";
import ContextualMenu from "../ContextualMenu";

export type CellContextualMenuProps = {
  gridApi: GridApi;
  anchorPosition: PopoverPosition;
  onCopy: () => void;
  onCopyRow: () => void;
  onCopyRange: (withHeaders?: boolean) => void;
  onClose: () => void;
  showRangesOptions?: boolean;
  customItems?: ContextualMenuItem[];
};

const CellContextualMenu: React.FunctionComponent<CellContextualMenuProps> = (
  props
) => {
  const {
    anchorPosition,
    onCopy,
    onCopyRow,
    onCopyRange,
    onClose,
    showRangesOptions,
    customItems,
  } = props;

  return (
    <ContextualMenu
      anchorPosition={anchorPosition}
      items={[
        ...[
          {
            content: "Copy Cell value",
            onClick: () => onCopy(),
          },
          {
            content: "Copy Row values",
            onClick: () => onCopyRow(),
          },
          ...(showRangesOptions
            ? [
                {
                  content: "Copy Selection",
                  onClick: () => onCopyRange(),
                },
                {
                  content: "Copy Selection With Headers",
                  onClick: () => onCopyRange(true),
                },
              ]
            : []),
        ],
        ...(customItems || []),
      ]}
      onClose={() => onClose()}
    />
  );
};

export default CellContextualMenu;
