import React from "react";
import { PopoverPosition } from "@material-ui/core";
import { GridApi } from "ag-grid-community";
import ContextualMenu from "../ContextualMenu";
import { ContextualMenuItem, TableActionMethods } from "../../types";
import { getHeaderContextualMenuItems } from "../../utils/contextual-menu";

export type HeaderContextualMenuProps = {
  gridApi: GridApi;
  contextualMenuAnchorPosition: PopoverPosition;
  onClose: () => void;
  disableFilters?: boolean;
  fixedColumns?: boolean;
  customItems?: ContextualMenuItem[];
} & TableActionMethods;

const HeaderContextualMenu: React.FunctionComponent<HeaderContextualMenuProps> = (
  props
) => {
  const {
    gridApi,
    contextualMenuAnchorPosition,
    onClose,
    onCustomizeColumns,
    onFilterDataGrid,
    bestFit,
    wrapText,
    removeThisColumn,
    freezeColumns,
    setSort,
    toggleSearchPanel,
    isSearchPanelShown,
    resetTable,
    handleExport,
    disableFilters,
    fixedColumns,
    customItems,
  } = props;

  return (
    <ContextualMenu
      anchorPosition={contextualMenuAnchorPosition}
      items={[
        ...getHeaderContextualMenuItems(
          {
            onCustomizeColumns,
            onFilterDataGrid,
            bestFit,
            wrapText,
            removeThisColumn,
            freezeColumns,
            setSort,
            toggleSearchPanel,
            isSearchPanelShown,
            resetTable,
            handleExport,
          },
          {
            disableFilters,
            fixedColumns,
          },
          gridApi
        ),
        ...(customItems || []),
      ]}
      onClose={() => onClose()}
    />
  );
};

export default HeaderContextualMenu;
