import React from "react";
import { Menu, MenuItem, PopoverPosition } from "@material-ui/core";
import NestedMenuItem from "material-ui-nested-menu-item";
import SearchBar from "../../SearchBar";
import { ContextualMenuItem } from "../../types";
import "./styles.scss";

export type ContextualMenuProps = {
  items: ContextualMenuItem[];
  onClose: () => void;
  anchorEl?: HTMLElement | null;
  anchorPosition?: PopoverPosition;
  onExited?: () => void;
  maxHeight?: number;
  searchText?: string;
  onSearchTextChange?: (newValue: string) => void;
  className?: string;
};

const ContextualMenu: React.FunctionComponent<ContextualMenuProps> = (
  props
) => {
  const {
    items,
    onClose,
    anchorEl,
    anchorPosition,
    onExited,
    maxHeight,
    searchText,
    onSearchTextChange,
    className,
  } = props;

  const isMenuOpen = !!anchorEl || !!anchorPosition;

  const renderItem = (item: ContextualMenuItem) => {
    if (item.items) {
      return (
        <NestedMenuItem
          label={item.content}
          parentMenuOpen={isMenuOpen}
          onClick={item.onClick}
          disabled={item.disabled}
        >
          {item.items.map((subItem) => renderItem(subItem))}
        </NestedMenuItem>
      );
    }
    return item.noWrap
      ? item.content
      : React.createElement(
          MenuItem,
          {
            onClick: item.disabled ? undefined : item.onClick,
            disabled: item.disabled,
          },
          item.content
        );
  };

  return (
    <Menu
      open={isMenuOpen}
      anchorReference={anchorEl ? "anchorEl" : "anchorPosition"}
      anchorEl={anchorEl}
      anchorPosition={anchorPosition}
      onClose={onClose}
      onExited={onExited}
      PaperProps={
        maxHeight
          ? {
              style: {
                maxHeight,
              },
            }
          : undefined
      }
      className={className}
      onContextMenu={(event) => {
        event.preventDefault();
        event.stopPropagation();
        if (
          event.target &&
          !(event.target as HTMLElement).closest(".MuiPopover-paper")
        ) {
          onClose();
        }
      }}
    >
      {searchText !== undefined && onSearchTextChange && (
        <MenuItem className="search-bar-item">
          <SearchBar
            value={searchText}
            onChange={(newValue) => onSearchTextChange(newValue)}
          />
        </MenuItem>
      )}
      {items.map((item) => renderItem(item))}
    </Menu>
  );
};

export default ContextualMenu;
