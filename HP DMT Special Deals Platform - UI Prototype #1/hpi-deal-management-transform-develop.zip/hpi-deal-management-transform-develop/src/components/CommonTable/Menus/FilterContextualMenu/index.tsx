import { MenuItem, PopoverPosition } from "@material-ui/core";
import { GridApi, RowNode } from "ag-grid-community";
import moment from "moment";
import React, { useCallback, useEffect, useState } from "react";
import { ContextualMenuItem, TableColumn } from "../../types";
import ContextualMenu from "../ContextualMenu";
import "./styles.scss";

export type FilterContextualMenuProps = {
  gridApi: GridApi;
  columnKey: string;
  anchorPosition: PopoverPosition;
  searchText: string;
  onSearchTextChange: (newValue: string) => void;
  onClose: () => void;
  onFilterDataGrid: () => void;
  tableColumn?: TableColumn;
};

const FilterContextualMenu: React.FunctionComponent<FilterContextualMenuProps> = (
  props
) => {
  const {
    gridApi,
    anchorPosition,
    searchText,
    columnKey,
    onSearchTextChange,
    onClose,
    onFilterDataGrid,
    tableColumn,
  } = props;

  const [contextualMenuItems, setContextualMenuItems] = useState<
    ContextualMenuItem[]
  >([]);

  const getColumnRows = useCallback(() => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const rows = (gridApi.getModel() as any).rowsToDisplay as RowNode[];
    return rows.map((row) => row.data[columnKey]);
  }, [gridApi, columnKey]);

  const updateContextualMenuItems = useCallback(() => {
    setContextualMenuItems([
      {
        content: (
          <div>
            <MenuItem
              className="clear-filter-item"
              disabled={searchText === ""}
              onClick={() => searchText !== "" && onSearchTextChange("")}
            >
              Clear Filter
            </MenuItem>
            <MenuItem
              className="filter-data-grid-item"
              onClick={() => {
                onFilterDataGrid();
                onClose();
              }}
            >
              Filter Data Grid
            </MenuItem>
            <div
              style={{
                maxHeight: `${36 * 6}px`,
                overflow: "auto",
              }}
            >
              {getColumnRows()
                .slice(0, 100)
                .map((content, index) => {
                  const formattedContent =
                    tableColumn && tableColumn.cellType === "date"
                      ? moment(content).format("MM/DD/YYYY - hh:mm A")
                      : content;
                  return (
                    <MenuItem
                      key={index}
                      onClick={() =>
                        onSearchTextChange(String(formattedContent))
                      }
                    >
                      <span className="filter-item-content">
                        {formattedContent}
                      </span>
                    </MenuItem>
                  );
                })}
            </div>
          </div>
        ),
        noWrap: true,
      },
    ]);
  }, [
    searchText,
    getColumnRows,
    onSearchTextChange,
    onFilterDataGrid,
    onClose,
    tableColumn,
  ]);

  useEffect(() => {
    updateContextualMenuItems();
  }, [updateContextualMenuItems]);

  return (
    <ContextualMenu
      className="filter-contextual-menu"
      searchText={searchText}
      onSearchTextChange={(newValue) => onSearchTextChange(newValue)}
      anchorPosition={anchorPosition}
      items={contextualMenuItems}
      onClose={() => onClose()}
      onExited={() => {
        updateContextualMenuItems();
      }}
    />
  );
};

export default FilterContextualMenu;
