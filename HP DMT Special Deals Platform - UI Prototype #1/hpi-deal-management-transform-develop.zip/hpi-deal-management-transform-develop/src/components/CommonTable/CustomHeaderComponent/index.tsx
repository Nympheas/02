/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */
// eslint-disable jsx-a11y/click-events-have-key-events
import React, { useCallback, useEffect, useState } from "react";
import { Column, GridApi } from "ag-grid-community";
import { ImFilter } from "react-icons/im";
import { PopoverPosition } from "@material-ui/core";
import ArrowUpwardIcon from "@material-ui/icons/ArrowUpward";
import ArrowDownwardIcon from "@material-ui/icons/ArrowDownward";
import "./styles.scss";

export type CustomHeaderComponentProps = {
  api: GridApi;
  column: Column;
  displayName: string;
  enableSorting: boolean;
  onOpenFilters:
    | ((
        anchorPosition: PopoverPosition,
        columnKey: string,
        api: GridApi,
        onClose: () => void
      ) => void)
    | null;
  isFilterActive: (colId: string) => boolean;
  setSort: (order: string, shiftKey: boolean) => void;
};

const CustomHeaderComponent: React.FunctionComponent<CustomHeaderComponentProps> = (
  props
) => {
  const {
    api,
    column,
    displayName,
    enableSorting,
    onOpenFilters,
    isFilterActive,
    setSort,
  } = props;

  const [ascSort, setAscSort] = useState("inactive");
  const [descSort, setDescSort] = useState("inactive");
  const [isFilterMenuOpen, setFilterMenuOpen] = useState(false);

  const onSortChanged = useCallback(() => {
    setAscSort(column.isSortAscending() ? "active" : "inactive");
    setDescSort(column.isSortDescending() ? "active" : "inactive");
  }, [column]);

  const onSortRequested = (
    order: "asc" | "desc" | "",
    event: React.MouseEvent | React.TouchEvent
  ) => {
    setSort(order, event.shiftKey);
  };

  useEffect(() => {
    column.addEventListener("sortChanged", onSortChanged);
    onSortChanged();
  }, [onSortChanged, column]);

  let sort = null;
  if (enableSorting) {
    sort = (
      <div className="sorting">
        <div className={`${ascSort}`}>
          <ArrowUpwardIcon />
        </div>
        <div className={`${descSort}`}>
          <ArrowDownwardIcon />
        </div>
      </div>
    );
  }

  const getNextSort = () => {
    if (column.isSortNone()) {
      return "asc";
    }
    if (column.isSortAscending()) {
      return "desc";
    }
    return "";
  };

  if (displayName === "Selected") {
    return <div />;
  }

  return (
    <div
      className={`custom-header${isFilterMenuOpen ? " filter-menu-open" : ""}`}
      onClick={(event) => {
        onSortRequested(getNextSort(), event);
      }}
      onTouchEnd={(event) => {
        onSortRequested(getNextSort(), event);
      }}
    >
      <div className="text-wrap">{displayName}</div>
      {sort}
      {onOpenFilters !== null && (
        <ImFilter
          className={`filter-icon${
            isFilterActive(column.getColId()) ? " active" : ""
          }`}
          onClick={(event) => {
            event.preventDefault();
            event.stopPropagation();
            onOpenFilters(
              {
                top: event.clientY - 4,
                left: event.clientX - 2,
              },
              column.getColId(),
              api,
              () => {
                setFilterMenuOpen(false);
              }
            );
            setFilterMenuOpen(true);
          }}
        />
      )}
    </div>
  );
};

export default CustomHeaderComponent;
