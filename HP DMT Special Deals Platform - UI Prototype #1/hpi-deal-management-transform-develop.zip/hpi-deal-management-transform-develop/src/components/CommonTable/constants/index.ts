/* eslint-disable import/prefer-default-export */
// Operators present for filtering data, ids set according to https://www.ag-grid.com/react-grid/filter-text/#text-filter-parameters
export const OPERATORS = [
  { id: "equal", label: "Equals to", hasOperand: true },
  { id: "notEqual", label: "Does not equal", hasOperand: true },
  // { id: "IS_LIKE", label: "Is like", hasOperand: true },
  // { id: "IS_NOT_LIKE", label: "Is not like", hasOperand: true },
  { id: "greaterThan", label: "Is greater than", hasOperand: true },
  {
    id: "greaterThanOrEqual",
    label: "Is greater than or equal to",
    hasOperand: true,
  },
  { id: "lessThan", label: "Is lesser than", hasOperand: true },
  {
    id: "lessThanOrEqual",
    label: "Is lesser than or equal to",
    hasOperand: true,
  },
  { id: "contains", label: "Contains", hasOperand: true },
  { id: "notContains", label: "Not contains", hasOperand: true },
  { id: "startsWith", label: "Starts with", hasOperand: true },
  { id: "endsWith", label: "Ends with", hasOperand: true },
  { id: "empty", label: "Is empty", hasOperand: false },
] as const;
