import React, { useCallback, useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Grid,
  List,
  ListItem,
  ListItemText,
  Select,
  MenuItem,
  FormControl,
  makeStyles,
  createStyles,
  InputLabel,
  TextField,
  Paper,
} from "@material-ui/core";
import DeleteSharpIcon from "@material-ui/icons/DeleteSharp";
import { Column } from "ag-grid-community";
import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
} from "@material-ui/pickers";
import DateFnsUtils from "@date-io/date-fns";
import moment from "moment";
import "./styles.scss";
import { FilterOperatorId, Filters, TableColumn } from "../../types";
import { OPERATORS } from "../../constants";

/**
 * CSS Classes using Material UI makeStyles
 */
const useStyles = makeStyles(() =>
  createStyles({
    formControl: {
      minWidth: 360,
      display: "flex",
      marginTop: 12,
    },
    buttonAdd: {
      marginTop: 24,
    },
    paperCol: {
      minWidth: 360,
      minHeight: 300,
    },
    delete: {
      float: "right",
      cursor: "pointer",
      margin: 8,
    },
  })
);

export type FilterDataProps = {
  onClose: () => void;
  filters: Filters[];
  columns: Column[];
  tableColumns: TableColumn[];
  setAllFilters: (newFilters: Filters[]) => void;
};

export const FilterDataGrid: React.FC<FilterDataProps> = ({
  onClose,
  filters,
  columns,
  tableColumns,
  setAllFilters,
}) => {
  const classes = useStyles();
  const [checked, setChecked] = useState<string[]>([]);
  const [selectedColumn, setSelectedColumn] = useState<string | undefined>();
  const [selectedOperator, setSelectedOperator] = useState<
    string | undefined
  >();
  const [condition, setCondition] = useState<string | undefined>();
  const [filtersCopy, setFiltersCopy] = useState<Filters[]>(filters || []);

  const handleSelectedColumnChange = (
    event: React.ChangeEvent<{ value: unknown }>
  ) => {
    setSelectedColumn(event.target.value as string);
  };

  const handleSelectedOperatorChange = (
    event: React.ChangeEvent<{ value: unknown }>
  ) => {
    setSelectedOperator(event.target.value as string);
  };

  const handleConditionChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setCondition(event.target.value);
  };

  const showCondition = selectedOperator
    ? OPERATORS.find((operator) => selectedOperator === operator.id)?.hasOperand
    : false;

  const addFilter = useCallback(() => {
    setFiltersCopy([
      ...filtersCopy,
      {
        id: selectedColumn || "",
        value: {
          operator: selectedOperator as FilterOperatorId,
          condition,
        },
      },
    ]);
  }, [filtersCopy, selectedColumn, selectedOperator, condition]);

  const handleToggle = (value: string) => () => {
    const currentIndex = checked.indexOf(value);
    const newChecked = [...checked];

    if (currentIndex === -1) {
      newChecked.push(value);

      // Populate form with clicked value
      const option: Filters = JSON.parse(value);

      setSelectedColumn(option.id);
      if (option.value) {
        if (option.value.condition) {
          setCondition(option.value.condition);
        }
        if (option.value.operator) {
          setSelectedOperator(option.value.operator);
        }
      }
    } else {
      newChecked.splice(currentIndex, 1);
    }

    setChecked(newChecked);
  };

  const deleteChecked = () => {
    setFiltersCopy(
      filtersCopy.filter((filter) => !checked.includes(JSON.stringify(filter)))
    );
    setChecked([]);
  };

  const applyFilters = () => {
    setAllFilters(filtersCopy);
    onClose();
  };

  const showDatePicker = (() => {
    if (
      !selectedOperator ||
      !([
        "greaterThan",
        "greaterThanOrEqual",
        "lessThan",
        "lessThanOrEqual",
      ] as FilterOperatorId[]).includes(selectedOperator as FilterOperatorId)
    ) {
      return false;
    }
    if (selectedColumn) {
      const col = tableColumns.find((column) => column.key === selectedColumn);
      if (col) {
        return col.cellType === "date";
      }
    }
    return false;
  })();

  const numberInput = (() => {
    const col = tableColumns.find((column) => column.key === selectedColumn);
    if (col) {
      return col.cellType === "number";
    }
    return false;
  })();

  return (
    <Dialog
      open
      onClose={onClose}
      fullWidth
      maxWidth="md"
      className="filter-data-grid-dialog"
    >
      <DialogTitle id="alert-dialog-title">
        Set Filter Conditions
        <DeleteSharpIcon
          className={classes.delete}
          onClick={() => deleteChecked()}
          color={filtersCopy.length && checked.length ? "primary" : "disabled"}
        />
      </DialogTitle>
      <DialogContent>
        <Grid container justify="space-between">
          <Grid item>
            <FormControl className={classes.formControl}>
              <InputLabel htmlFor="age-native-simple">Column</InputLabel>
              <Select
                labelId="select-label-column"
                value={selectedColumn || ""}
                onChange={handleSelectedColumnChange}
                placeholder="Select Column"
              >
                {columns.map((column) => (
                  <MenuItem key={column.getColId()} value={column.getColId()}>
                    {column.getColDef().headerName || ""}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <FormControl className={classes.formControl}>
              <InputLabel htmlFor="age-native-simple">Operator</InputLabel>
              <Select
                labelId="select-label-operator"
                value={selectedOperator || ""}
                onChange={handleSelectedOperatorChange}
                placeholder="Select Operator"
              >
                {OPERATORS.map((operator) => (
                  <MenuItem key={operator.id} value={operator.id}>
                    {operator.label}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            {showCondition && (
              <FormControl className={classes.formControl}>
                {showDatePicker ? (
                  <MuiPickersUtilsProvider utils={DateFnsUtils}>
                    <KeyboardDatePicker
                      value={
                        condition
                          ? moment(condition, "MM/DD/YYYY - hh:mm A").toDate()
                          : null
                      }
                      format="MM/dd/yyyy"
                      onChange={(newDate) =>
                        newDate
                          ? setCondition(
                              moment(newDate as Date).format(
                                "MM/DD/YYYY - hh:mm A"
                              )
                            )
                          : setCondition(undefined)
                      }
                    />
                  </MuiPickersUtilsProvider>
                ) : (
                  <TextField
                    label="Condition"
                    value={condition}
                    onChange={handleConditionChange}
                    type={numberInput ? "number" : "text"}
                  />
                )}
              </FormControl>
            )}

            <Button
              className={classes.buttonAdd}
              onClick={addFilter}
              color="secondary"
              disabled={
                !selectedColumn ||
                !selectedOperator ||
                (showCondition ? !condition : false)
              }
              variant="outlined"
            >
              Add
            </Button>
          </Grid>
          <Grid item>
            <Paper className={classes.paperCol}>
              <List dense component="div" role="list">
                {filtersCopy.map((filter) => (
                  <ListItem
                    id={JSON.stringify(filter)}
                    key={JSON.stringify(filter)}
                    button
                    onClick={handleToggle(JSON.stringify(filter))}
                    className={
                      checked.includes(JSON.stringify(filter))
                        ? "selected-filter"
                        : ""
                    }
                  >
                    <ListItemText
                      id={filter.id}
                      primary={`${
                        columns
                          .find((column) => column.getColId() === filter.id)
                          ?.getColDef().headerName || ""
                      } ${
                        OPERATORS.find(
                          (operator) => filter.value.operator === operator.id
                        )?.label || ""
                      } ${
                        filter.value.condition ? filter.value.condition : ""
                      }`}
                    />
                  </ListItem>
                ))}
              </List>
            </Paper>
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} color="primary" variant="outlined">
          Cancel
        </Button>
        <Button
          onClick={applyFilters}
          color="primary"
          autoFocus
          variant="outlined"
        >
          Apply
        </Button>
      </DialogActions>
    </Dialog>
  );
};
