import React, { useState } from "react";
import {
  Button,
  Checkbox,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControlLabel,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Paper,
} from "@material-ui/core";
import { TableColumn } from "../../types";
import "./styles.scss";

export type WrapTextProps = {
  /** Fields sorted by the length of the maximum length of the content. */
  columns: TableColumn[];
  onWrapChanged: (newColumnsChecked: string[]) => void;
  onClose: () => void;
};

const getCheckedColumns = (columns: TableColumn[]) =>
  columns.filter((column) => !!column.wrapText);

const WrapText: React.FunctionComponent<WrapTextProps> = (props) => {
  const { columns, onWrapChanged, onClose } = props;

  const [checked, setChecked] = useState<string[]>(
    getCheckedColumns(columns).map((column) => column.key)
  );
  const [selectAll, setSelectAll] = useState<boolean>(
    getCheckedColumns(columns).length === columns.length
  );

  const isChecked = (key: string): boolean => checked.includes(key);

  return (
    <Dialog
      className="wrap-text-modal"
      open
      onClose={onClose}
      fullWidth
      maxWidth="md"
    >
      <DialogTitle>Word Wrap</DialogTitle>
      <DialogContent>
        <div>
          <FormControlLabel
            control={
              <Checkbox
                checked={selectAll}
                onChange={(event) => {
                  const newSelectAll = event.target.checked;
                  setSelectAll(newSelectAll);
                  if (newSelectAll) {
                    setChecked(columns.map((column) => column.key));
                  } else {
                    setChecked([]);
                  }
                }}
              />
            }
            label="Select All"
          />
          <Paper>
            <List dense component="div" role="list" className="column-list">
              {columns.map((column: TableColumn, index) => {
                const labelId = `wrap-text-list-item-${column.key}-label`;

                return (
                  <ListItem key={index} role="listitem">
                    <ListItemIcon>
                      <Checkbox
                        checked={isChecked(column.key)}
                        inputProps={{ "aria-labelledby": labelId }}
                        onChange={(event) => {
                          const newChecked = checked.slice();
                          if (newChecked.includes(column.key)) {
                            if (!event.target.checked) {
                              newChecked.splice(
                                newChecked.indexOf(column.key),
                                1
                              );
                            }
                          } else if (event.target.checked) {
                            newChecked.push(column.key);
                          }
                          if (selectAll && newChecked.length < columns.length) {
                            setSelectAll(false);
                          }
                          if (
                            !selectAll &&
                            newChecked.length === columns.length
                          ) {
                            setSelectAll(true);
                          }
                          setChecked(newChecked);
                        }}
                      />
                    </ListItemIcon>
                    <ListItemText id={labelId} primary={column.label} />
                  </ListItem>
                );
              })}
              <ListItem />
            </List>
          </Paper>
        </div>
      </DialogContent>
      <DialogActions>
        <Button
          variant="contained"
          color="primary"
          onClick={() =>
            onWrapChanged(
              selectAll ? columns.map((column) => column.key) : checked
            )
          }
        >
          Wrap
        </Button>
        <Button
          variant="outlined"
          color="secondary"
          onClick={() => onWrapChanged([])}
        >
          Remove All Word Wraps
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default WrapText;
