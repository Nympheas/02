import React from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Grid,
  Checkbox,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Paper,
  Typography,
  makeStyles,
} from "@material-ui/core";
import { Column } from "ag-grid-community";

/**
 * CSS Classes using Material UI makeStyles
 */
const useStyles = makeStyles({
  listColumn: {
    width: 220,
    height: 300,
    overflowY: "auto",
  },
});

// Find compliment of intersection
function not(a: Column[], b: Column[]) {
  return a.filter((value) => b.indexOf(value) === -1);
}

// Find intersection
function intersection(a: Column[], b: Column[]) {
  return a.filter((value) => b.indexOf(value) !== -1);
}

interface CustomizeColumnsProps {
  isOpen: boolean;
  onClose: () => void;
  columns: Column[];
  setHiddenColumns: (hiddenColumns: Column[]) => void;
}

const CustomizeColumns: React.FC<CustomizeColumnsProps> = ({
  isOpen,
  onClose,
  columns,
  setHiddenColumns,
}) => {
  const classes = useStyles();
  const [checked, setChecked] = React.useState<Column[]>([]);
  const [left, setLeft] = React.useState<Column[]>(
    columns.filter((column) =>
      column.getColId() ? !column.isVisible() : false
    )
  );
  const [right, setRight] = React.useState<Column[]>(
    columns.filter((column) => (column.getColId() ? column.isVisible() : false))
  );

  const leftChecked = intersection(checked, left);
  const rightChecked = intersection(checked, right);

  // Handle toggle checked
  const handleToggle = (value: Column) => () => {
    const currentIndex = checked.indexOf(value);
    const newChecked = [...checked];

    if (currentIndex === -1) {
      newChecked.push(value);
    } else {
      newChecked.splice(currentIndex, 1);
    }

    setChecked(newChecked);
  };

  // Shift checked from right
  const handleCheckedRight = () => {
    setRight(right.concat(leftChecked));
    setLeft(not(left, leftChecked));
    setChecked(not(checked, leftChecked));
  };

  // Shift checked from left
  const handleCheckedLeft = () => {
    setLeft(left.concat(rightChecked));
    setRight(not(right, rightChecked));
    setChecked(not(checked, rightChecked));
  };

  // Shift to all visible
  const handleAllRight = () => {
    setRight(right.concat(left));
    setLeft([]);
  };

  // Shift to all hidden
  const handleAllLeft = () => {
    setLeft(left.concat(right));
    setRight([]);
  };

  // Custom List of columns Hidden/Visible
  const customList = (items: Column[]) => (
    <Paper>
      <List dense component="div" role="list" className={classes.listColumn}>
        {items.map((value: Column, index) => {
          const labelId = `transfer-list-item-${value}-label`;

          return (
            <ListItem
              key={index}
              role="listitem"
              button
              onClick={handleToggle(value)}
            >
              <ListItemIcon>
                <Checkbox
                  checked={checked.indexOf(value) !== -1}
                  tabIndex={-1}
                  disableRipple
                  inputProps={{ "aria-labelledby": labelId }}
                />
              </ListItemIcon>
              <ListItemText
                id={labelId}
                primary={value.getColDef().headerName}
              />
            </ListItem>
          );
        })}
        <ListItem />
      </List>
    </Paper>
  );

  const updateHiddenColumns = () => {
    setHiddenColumns(left);
    onClose();
  };

  // Render UI for Customize Columns Modal
  return (
    <Dialog open={isOpen} onClose={onClose} fullWidth>
      <DialogTitle id="alert-dialog-title">Customize Columns</DialogTitle>
      <DialogContent>
        <Grid container spacing={2} justify="space-between" alignItems="center">
          <Grid item>
            <Typography variant="h6">Hidden</Typography>
            {customList(left)}
          </Grid>
          <Grid item>
            <Grid container direction="column" alignItems="center">
              <Button
                variant="outlined"
                size="small"
                onClick={handleAllRight}
                disabled={left.length === 0}
                aria-label="move all right"
              >
                ≫
              </Button>
              <Button
                variant="outlined"
                size="small"
                onClick={handleCheckedRight}
                disabled={leftChecked.length === 0}
                aria-label="move selected right"
              >
                &gt;
              </Button>
              <Button
                variant="outlined"
                size="small"
                onClick={handleCheckedLeft}
                disabled={rightChecked.length === 0}
                aria-label="move selected left"
              >
                &lt;
              </Button>
              <Button
                variant="outlined"
                size="small"
                onClick={handleAllLeft}
                disabled={right.length === 0}
                aria-label="move all left"
              >
                ≪
              </Button>
            </Grid>
          </Grid>
          <Grid item>
            <Typography variant="h6">Visible</Typography>
            {customList(right)}
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} color="primary">
          Cancel
        </Button>
        <Button onClick={updateHiddenColumns} color="primary" autoFocus>
          Apply
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default CustomizeColumns;
