import React from "react";
import { Popover } from "@material-ui/core";
import "./styles.scss";

export type HoverPopupProps = {
  anchorEl: HTMLElement | null;
  onClose: () => void;
};

const HoverPopup: React.FunctionComponent<HoverPopupProps> = ({
  anchorEl,
  onClose,
  children,
}) => {
  return (
    <Popover
      className="hover-popup"
      open={!!anchorEl}
      anchorEl={anchorEl}
      onClose={onClose}
      disableRestoreFocus
      anchorOrigin={{
        vertical: "center",
        horizontal: "center",
      }}
      transformOrigin={{
        vertical: "top",
        horizontal: "left",
      }}
    >
      {children}
    </Popover>
  );
};

export default HoverPopup;
