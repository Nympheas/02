import {
  CellClassParams,
  EditableCallbackParams,
  GridApi,
  ColumnApi,
} from "ag-grid-community";
import React from "react";
import { OPERATORS } from "../constants";

export type TableCellType = "text" | "number" | "date" | "dropdown";

export type TableColumnToggleableStatus = {
  statusToggledKey: string;
  onStatusToggled: (
    newStatus: boolean,
    rowIndex: number,
    api?: GridApi,
    columnApi?: ColumnApi
  ) => void;
};

export type CustomIconParams = {
  api: GridApi;
  columnApi;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  value: any;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  data: any;
};

export type BaseTableColumn = {
  key: string;
  label: string;
  cellType?: TableCellType;
  isCellEditingDisabled?: (
    params: CellClassParams | EditableCallbackParams | ICellRendererParams
  ) => boolean;
  isFormatValid?: (value: string | number) => string[] | null;
  onDoubleClick?: (event: React.MouseEvent) => void;
  customIcon?: {
    getContent: (params: CustomIconParams) => JSX.Element;
    tooltipMessage?: (params: CustomIconParams) => JSX.Element | string;
    onClick?: (event: React.MouseEvent) => void;
  };
  editable?: boolean;
  wrapText?: boolean;
  toggleableStatus?: TableColumnToggleableStatus;
};

export type TableColumnWithText = BaseTableColumn & {
  cellType?: "text" | "number";
};

export type TableColumnWithDate = BaseTableColumn & {
  cellType: "date";
};

export type TableColumnWithDropdown = BaseTableColumn & {
  cellType: "dropdown";
  dropdownOptions: string[];
};

export type TableColumn =
  | TableColumnWithText
  | TableColumnWithDate
  | TableColumnWithDropdown;

export type TableActionMethods = {
  onCustomizeColumns: () => void;
  onFilterDataGrid: () => void;
  bestFit: (thisColumn?: boolean) => void;
  wrapText: () => void;
  removeThisColumn: () => void;
  freezeColumns: (frozenColumns: number | null) => void;
  setSort: (order: string, shiftKey: boolean) => void;
  toggleSearchPanel: () => void;
  isSearchPanelShown: boolean;
  resetTable: () => void;
  handleExport: () => void;
};

export type PartialTableActionMethods = {
  onCustomizeColumns?: () => void;
  onFilterDataGrid?: () => void;
  bestFit?: (thisColumn?: boolean) => void;
  wrapText?: () => void;
  removeThisColumn?: () => void;
  freezeColumns?: (frozenColumns: number | null) => void;
  setSort?: (order: string, shiftKey: boolean) => void;
  toggleSearchPanel?: () => void;
  isSearchPanelShown?: boolean;
  resetTable?: () => void;
  handleExport?: (onlySelected?: boolean) => void;
};

export type TableClasses = {
  [rowIndex: number]: {
    className?: string;
    cellsClasses?: {
      [colId: string]: string;
    };
  };
};

// Filters

export type FilterOperatorId = typeof OPERATORS[number]["id"];

export type FilterOperator = {
  id: FilterOperatorId;
  label: typeof OPERATORS[number]["label"];
  hasOperand: typeof OPERATORS[number]["hasOperand"];
  type?: "text" | "number" | "date";
};

export type Filters = {
  id: string;
  value: { operator: FilterOperatorId; condition?: string };
};

// Table state

export type TableState = {
  filters: Filters[];
  columnState: ColumnState[];
  columns: TableColumn[];
  searchPanel?: {
    value: string;
    filter: string;
  };
};

// Custom Range Selection

export type SelectionRangeCell = {
  rowIndex: number;
  colId: string;
};

export type SelectionBorderSide = "top" | "bottom" | "right" | "left";

export type RangeSelectionMode = "ctrl" | "fill";

export type PartialSelectionRange = {
  selectionMode: RangeSelectionMode;
  start: SelectionRangeCell;
  end?: SelectionRangeCell;
};

export type SelectionRange = {
  start: SelectionRangeCell;
  end: SelectionRangeCell;
};

export type CellSelectionProps = {
  onMouseDown: React.MouseEventHandler<HTMLDivElement>;
  onClick?: React.MouseEventHandler<HTMLDivElement>;
};

// Contextual menu

export type ContextualMenuItem = {
  content: string | JSX.Element | JSX.Element[];
  items?: ContextualMenuItem[];
  noWrap?: boolean;
  onClick?: (event: React.MouseEvent) => void;
  disabled?: boolean;
};
