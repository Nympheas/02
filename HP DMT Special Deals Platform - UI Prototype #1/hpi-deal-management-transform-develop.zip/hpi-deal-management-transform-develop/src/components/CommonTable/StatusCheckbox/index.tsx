import React, { useState } from "react";
import { Checkbox } from "@material-ui/core";

export type StatusCheckboxProps = {
  checked: boolean;
  onChange: (newChecked: boolean) => void;
};

const StatusCheckbox: React.FunctionComponent<StatusCheckboxProps> = (
  props
) => {
  const { checked: initialChecked, onChange } = props;

  const [checked, setChecked] = useState<boolean>(initialChecked);

  const handleChange = (newChecked: boolean) => {
    setChecked(newChecked);
    onChange(newChecked);
  };

  return (
    <Checkbox
      checked={checked}
      onDoubleClick={(event) => {
        event.preventDefault();
        event.stopPropagation();
      }}
      onChange={(event) => {
        handleChange(event.target.checked);
        const cell = event.target.closest(".ag-cell");
        if (cell) {
          if (!cell.classList.contains("edited")) {
            cell.classList.add("edited");
          }
        }
      }}
      color="primary"
    />
  );
};

export default StatusCheckbox;
