/* eslint-disable @typescript-eslint/no-explicit-any */
import { CellPosition, Column, ColumnApi, GridApi } from "ag-grid-community";
import * as _ from "lodash";
import moment from "moment";
import { SelectionRange, SelectionRangeCell, TableColumn } from "../types";

const TAB_CHAR = "	";

// Helper functions

export const getAllDisplayedColumns = (
  columnApi: ColumnApi,
  includeSelected?: boolean
): Column[] => {
  let allDisplayedCols = columnApi.getAllDisplayedVirtualColumns();
  if (!includeSelected) {
    allDisplayedCols = allDisplayedCols.filter(
      (column) => column.getColId() !== "selected-column"
    );
  }
  // Move pinned columns to the beginning of the array
  const pinnedColumns = allDisplayedCols.filter((column) =>
    column.isPinnedLeft()
  );
  if (pinnedColumns.length > 0) {
    const notPinnedColumns = allDisplayedCols.filter(
      (column) => !column.isPinnedLeft()
    );
    allDisplayedCols = [...pinnedColumns, ...notPinnedColumns];
  }
  return allDisplayedCols;
};

// Copy

export const getStrFromSelection = (
  selectedRows: any[],
  displayedColumns: Column[],
  withHeaders?: "key" | "readable"
): string => {
  let finalStr = "";
  if (withHeaders) {
    finalStr = `${displayedColumns.map(
      (col, index) =>
        `${
          withHeaders === "key" ? col.getColId() : col.getColDef().headerName
        }${index < displayedColumns.length - 1 ? TAB_CHAR : ""}`
    )}`.replace(new RegExp(`${TAB_CHAR},`, "g"), TAB_CHAR);
    finalStr += "\n";
  }
  selectedRows.forEach((row) => {
    const selectedRowData = displayedColumns.map((col) => row[col.getColId()]);
    selectedRowData.forEach((field, index) => {
      finalStr += `${field}${
        index < selectedRowData.length - 1 ? TAB_CHAR : ""
      }`;
    });
    finalStr += `\n`;
  });
  return finalStr;
};

export const copyRowsToClipboard = (
  selectedRows: any[],
  displayedColumns: Column[],
  withHeaders?: "key" | "readable"
): void => {
  const strToCopy = getStrFromSelection(
    selectedRows,
    displayedColumns,
    withHeaders
  );
  navigator.clipboard.writeText(strToCopy);
};

export const copyRowsFromSelectionRangesToClipboard = (
  selectionRanges: SelectionRange[],
  api: GridApi,
  columnApi: ColumnApi,
  withHeaders?: "key" | "readable"
): void => {
  let finalStr = "";
  const allDisplayedCols = getAllDisplayedColumns(columnApi);
  const getColIndexById = (colId: string) =>
    allDisplayedCols.findIndex((column) => column.getColId() === colId);
  selectionRanges.forEach((selectionRange) => {
    let { start, end } = selectionRange;
    let startColIndex = getColIndexById(start.colId);
    let endColIndex = getColIndexById(end.colId);
    if (startColIndex > endColIndex) {
      const temp = start;
      start = end;
      end = temp;
      startColIndex = getColIndexById(start.colId);
      endColIndex = getColIndexById(end.colId);
    }
    const displayedColumns = allDisplayedCols.slice(
      startColIndex,
      endColIndex + 1
    );

    const selectedRowsData = api
      .getRenderedNodes()
      .filter(
        (row) =>
          row.rowIndex !== null &&
          row.rowIndex >= start.rowIndex &&
          row.rowIndex <= end.rowIndex
      )
      .map((row) => row.data);
    const selectionStr = getStrFromSelection(
      selectedRowsData,
      displayedColumns,
      withHeaders
    );
    finalStr += `${selectionStr}`;
  });
  navigator.clipboard.writeText(finalStr);
};

// Paste

/**
 * Paste new content in place (for efficiency in large arrays)
 * @param rowData Row data
 * @param content Pasted content
 * @param start Start of paste (top-left cursor)
 * @param end Optionally, end of paste (bottom-right cursor)
 */
export const pasteData = (
  columnApi: ColumnApi,
  rowData: any[],
  content: string[][],
  tableColumns: TableColumn[],
  start: SelectionRangeCell,
  end?: SelectionRangeCell
): void => {
  if (
    content.length === 0 ||
    rowData.length === 0 ||
    _.entries(rowData[0]).length === 0
  ) {
    return;
  }
  const contentMaxCols = content[0].length;
  const columns = getAllDisplayedColumns(columnApi);
  // Calculate start & end columns
  let startColIndex = columns.findIndex(
    (column) => column.getColId() === start.colId
  );
  let endColIndex = end
    ? columns.findIndex((column) => column.getColId() === end.colId)
    : startColIndex + contentMaxCols - 1;
  if (endColIndex >= columns.length) {
    endColIndex = columns.length - 1;
  }
  if (startColIndex === -1 || endColIndex === -1) {
    return;
  }
  if (startColIndex > endColIndex) {
    const temp = endColIndex;
    endColIndex = startColIndex;
    startColIndex = temp;
  }
  // Calculate start & end rows
  let startRowIndex = start.rowIndex;
  let endRowIndex = end ? end.rowIndex : startRowIndex + content.length - 1;
  if (endRowIndex >= rowData.length) {
    endRowIndex = rowData.length - 1;
  }
  if (startRowIndex > endRowIndex) {
    const temp = endRowIndex;
    endRowIndex = startRowIndex;
    startRowIndex = temp;
  }
  for (let colIndex = startColIndex; colIndex <= endColIndex; colIndex += 1) {
    const colId = columns[colIndex].getColId();
    const tableColumn = tableColumns.find((col) => col.key === colId);
    if (!tableColumn) {
      // eslint-disable-next-line no-continue
      continue;
    }
    for (let rowIndex = startRowIndex; rowIndex <= endRowIndex; rowIndex += 1) {
      let sourceColIndex = colIndex - startColIndex;
      if (sourceColIndex >= contentMaxCols) {
        // Wrap around
        sourceColIndex %= contentMaxCols;
      }
      let sourceRowIndex = rowIndex - startRowIndex;
      if (sourceRowIndex >= content.length) {
        sourceRowIndex %= content.length;
      }
      let newContent: string | number = content[sourceRowIndex][sourceColIndex];
      // Check for type cell compatibility (text, dropdown & date)
      let compatibleWithCellType = true;
      switch (tableColumn.cellType) {
        case "date":
          // Check if it is valid date
          if (
            Number.isNaN(Number(newContent)) ||
            !moment(Number(newContent)).isValid()
          ) {
            compatibleWithCellType = false;
          } else {
            newContent = Number(newContent);
          }
          break;
        case "dropdown":
          // If the affected cell is a dropdown, check if the new content is part of the provided options
          if (!tableColumn.dropdownOptions.includes(newContent)) {
            compatibleWithCellType = false;
          }
          break;
        default:
          // Text
          break;
      }
      // Check if cell is editable/disabled & if new content is valid
      const editableAndValid =
        tableColumn.editable !== false &&
        (tableColumn.isFormatValid
          ? tableColumn.isFormatValid(newContent)
          : true) &&
        (tableColumn.isCellEditingDisabled
          ? !tableColumn.isCellEditingDisabled({
              value: rowData[rowIndex][colId],
              data: rowData[rowIndex],
            })
          : true);
      if (editableAndValid && compatibleWithCellType) {
        // eslint-disable-next-line no-param-reassign
        rowData[rowIndex][colId] = newContent;
      }
    }
  }
};

export const getPastedRowData = (
  columnApi: ColumnApi,
  selection: SelectionRange[] | CellPosition,
  columns: TableColumn[],
  rowData: any[]
): Promise<any[]> => {
  return navigator.clipboard.readText().then((clipboardContent) => {
    const lines = clipboardContent
      .split(/(\r\n|\r|\n)/g)
      .slice()
      .filter(
        (line) =>
          line !== "" && line !== "\n" && line !== "\r" && line !== "\r\n"
      );
    const isValid =
      lines.reduce((prev, curr) => {
        const numberOfCols = curr.split(/\t/g).length;
        if (!/^[a-zA-Z0-9_\-/ .\t]*$/m.test(curr)) {
          return -1;
        }
        if (prev >= 0) {
          if (prev === 0) {
            return numberOfCols;
          }
          return numberOfCols === prev ? numberOfCols : -1;
        }
        return -1;
      }, 0) !== -1;
    if (isValid) {
      const rows = lines.map((line) => line.split(/\t/g));
      const newRowData = rowData.slice();
      if (Array.isArray(selection)) {
        // Selection range paste
        selection.forEach((selectionRange) => {
          pasteData(
            columnApi,
            newRowData,
            rows,
            columns,
            selectionRange.start,
            selectionRange.end
          );
        });
      } else {
        // Paste relative to focused cell
        pasteData(columnApi, newRowData, rows, columns, {
          colId: selection.column.getColId(),
          rowIndex: selection.rowIndex,
        });
      }
      return newRowData;
    }
    return rowData;
  });
};
