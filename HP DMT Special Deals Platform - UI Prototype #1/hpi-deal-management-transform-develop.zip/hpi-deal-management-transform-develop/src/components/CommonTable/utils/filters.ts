/* eslint-disable no-nested-ternary */
/* eslint-disable import/prefer-default-export */
import { RowNode } from "ag-grid-community";
import moment from "moment";
import { Filters, TableColumn } from "../types";

export const filterRow = (
  filters: Filters[],
  columns: TableColumn[],
  node: RowNode
): boolean => {
  return filters.reduce((passesFilter, filter) => {
    if (!passesFilter) {
      return false;
    }
    const column = columns.find((col) => col.key === filter.id);
    let colData = node.data[filter.id];
    if (column) {
      if (column.cellType) {
        if (column.cellType === "number") {
          if (typeof colData !== "number") {
            colData = Number(colData);
          }
        } else if (column.cellType === "date") {
          colData = moment(colData).format("MM/DD/YYYY - hh:mm A");
        }
      }
    }
    if (colData !== undefined) {
      let localeCompare: number | null;
      if (column && column.cellType === "number") {
        const colDataNumber = Number(colData);
        const conditionNumber = Number(filter.value.condition as string);
        if (colDataNumber === conditionNumber) {
          localeCompare = 0;
        } else {
          localeCompare = colDataNumber > conditionNumber ? 1 : -1;
        }
      } else {
        localeCompare = filter.value.condition
          ? `${colData}`.localeCompare(filter.value.condition as string)
          : null;
      }
      let isDate: boolean | undefined;
      let isDateBefore: boolean | undefined;
      if (column) {
        if (column.cellType === "date") {
          isDate = true;
          isDateBefore = moment(
            filter.value.condition as string,
            "MM/DD/YYYY - hh:mm A"
          ).isBefore(moment(node.data[filter.id]));
        }
      }
      switch (filter.value.operator) {
        case "contains":
          return `${colData}`.includes(filter.value.condition as string);
        case "notContains":
          return !`${colData}`.includes(filter.value.condition as string);
        case "startsWith":
          return `${colData}`.startsWith(filter.value.condition as string);
        case "endsWith":
          return `${colData}`.endsWith(filter.value.condition as string);
        case "equal":
          return `${colData}` === (filter.value.condition as string);
        case "notEqual":
          return `${colData}` !== (filter.value.condition as string);
        case "greaterThan":
          return isDate
            ? (isDateBefore as boolean)
            : localeCompare !== null
            ? localeCompare === 1
            : true;
        case "greaterThanOrEqual":
          return isDate
            ? (isDateBefore as boolean) ||
                node.data[filter.id] === (filter.value.condition as string)
            : localeCompare !== null
            ? localeCompare >= 0
            : true;
        case "lessThan":
          return isDate
            ? !isDateBefore
            : localeCompare !== null
            ? localeCompare === -1
            : true;
        case "lessThanOrEqual":
          return isDate
            ? !isDateBefore ||
                node.data[filter.id] === (filter.value.condition as string)
            : localeCompare !== null
            ? localeCompare <= 0
            : true;
        case "empty":
          return !colData;
        default:
          return false;
      }
    } else if (filter.value.operator === "empty") {
      return true;
    }
    return true;
  }, true as boolean);
};
