import { GridApi } from "ag-grid-community";
import { ContextualMenuItem, PartialTableActionMethods } from "../types";

// Header

// eslint-disable-next-line import/prefer-default-export
export const getHeaderContextualMenuItems = (
  tableActionMethods: PartialTableActionMethods,
  options?: { fixedColumns?: boolean; disableFilters?: boolean },
  gridApi?: GridApi | null
): ContextualMenuItem[] => {
  const {
    onCustomizeColumns,
    onFilterDataGrid,
    bestFit,
    wrapText,
    removeThisColumn,
    freezeColumns,
    setSort,
    toggleSearchPanel,
    isSearchPanelShown,
    resetTable,
    handleExport,
  } = tableActionMethods;

  let fixedColumns = false;
  let disableFilters = false;
  if (options) {
    fixedColumns = !!options.fixedColumns;
    disableFilters = !!options.disableFilters;
  }

  const sortItems: ContextualMenuItem[] = setSort
    ? [
        {
          content: "Sort by",
          items: [
            {
              content: "Ascending",
              onClick: (event) => setSort("asc", event.shiftKey),
            },
            {
              content: "Descending",
              onClick: (event) => setSort("desc", event.shiftKey),
            },
          ],
        },
      ]
    : [];

  const customizeColumnsItems: ContextualMenuItem[] = [
    ...(onCustomizeColumns
      ? [
          {
            content: "Customize columns",
            onClick: () => onCustomizeColumns(),
          },
        ]
      : []),
    ...(removeThisColumn
      ? [
          {
            content: "Remove this column",
            onClick: () => removeThisColumn(),
          },
        ]
      : []),
  ];

  const filterDataGridItems: ContextualMenuItem[] = onFilterDataGrid
    ? [
        {
          content: "Filter Data Grid",
          onClick: () => onFilterDataGrid(),
        },
      ]
    : [];

  const freezeColumnsItems: ContextualMenuItem[] = freezeColumns
    ? [
        {
          content: "Freeze columns",
          items: [
            { content: "Unfreeze", onClick: () => freezeColumns(null) },
            { content: "1", onClick: () => freezeColumns(1) },
            { content: "2", onClick: () => freezeColumns(2) },
            { content: "3", onClick: () => freezeColumns(3) },
            { content: "4", onClick: () => freezeColumns(4) },
          ],
        },
      ]
    : [];

  const bestFitItems: ContextualMenuItem[] = (() => {
    const subItems: ContextualMenuItem[] = [];
    if (bestFit) {
      subItems.push({ content: "This column", onClick: () => bestFit(true) });
      subItems.push({ content: "All columns", onClick: () => bestFit() });
    }
    if (wrapText) {
      subItems.push({ content: "Wrap text", onClick: () => wrapText() });
    }
    return subItems.length > 0
      ? [
          {
            content: "Best fit",
            items: subItems,
          },
        ]
      : [];
  })();

  const searchPanelItems: ContextualMenuItem[] = toggleSearchPanel
    ? [
        {
          content: `${isSearchPanelShown ? "Hide" : "Show"} search panel`,
          onClick: () => toggleSearchPanel(),
        },
      ]
    : [];
  const clearSortingItems: ContextualMenuItem[] = setSort
    ? [
        {
          content: "Clear sorting",
          onClick: (event) => setSort("", event.shiftKey),
        },
      ]
    : [];
  const exportItems: ContextualMenuItem[] = handleExport
    ? [
        {
          content: "Export",
          items: gridApi
            ? [
                {
                  content: "Export all rows",
                  onClick: () => handleExport(),
                },
                {
                  content: "Export selected rows",
                  onClick: () => handleExport(true),
                  disabled: gridApi.getSelectedRows().length === 0,
                },
              ]
            : undefined,
        },
      ]
    : [];
  const resetTableItems: ContextualMenuItem[] = resetTable
    ? [
        {
          content: "Reset table",
          onClick: () => resetTable(),
        },
      ]
    : [];

  return [
    ...sortItems,
    ...(fixedColumns ? [] : customizeColumnsItems),
    ...(disableFilters ? [] : filterDataGridItems),
    ...freezeColumnsItems,
    ...bestFitItems,
    ...searchPanelItems,
    ...clearSortingItems,
    ...exportItems,
    ...resetTableItems,
  ];
};
