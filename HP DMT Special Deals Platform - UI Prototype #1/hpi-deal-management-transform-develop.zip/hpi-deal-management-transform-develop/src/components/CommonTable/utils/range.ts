import { SelectionBorderSide, SelectionRangeCell } from "../types";

export const getRangeSelectedClass = (side: SelectionBorderSide): string =>
  `ag-cell-range-${side}`;

export const getCellUnderMouse = (
  event: React.MouseEvent<HTMLDivElement>
): SelectionRangeCell | null => {
  const elementsUnderMouse = document.elementsFromPoint(
    event.clientX,
    event.clientY
  );
  const rowElem = elementsUnderMouse.find((cell) =>
    cell.classList.contains("ag-row")
  );
  const cellElem = elementsUnderMouse.find((cell) =>
    cell.classList.contains("ag-cell")
  );
  if (cellElem && rowElem) {
    const colIdAttr = cellElem.attributes.getNamedItem("col-id");
    const rowIndexAttr = rowElem.attributes.getNamedItem("row-index");
    if (colIdAttr && rowIndexAttr) {
      const cell: SelectionRangeCell = {
        colId: colIdAttr.value,
        rowIndex: Number(rowIndexAttr.value),
      };
      return cell;
    }
  }
  return null;
};
