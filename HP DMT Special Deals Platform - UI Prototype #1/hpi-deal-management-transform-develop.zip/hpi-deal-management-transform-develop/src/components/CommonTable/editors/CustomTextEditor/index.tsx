import React, {
  forwardRef,
  useImperativeHandle,
  useLayoutEffect,
  useState,
} from "react";
import { Button, FormControl, Input, Popover } from "@material-ui/core";
import { TableColumn } from "../../types";
import "./styles.scss";

export type CustomTextEditorProps = {
  value: string | number;
  column: TableColumn;
  stopEditing: () => void;
  eGridCell: HTMLDivElement;
};

const CustomTextEditor: React.FunctionComponent<CustomTextEditorProps> = forwardRef(
  (props, ref) => {
    const { value: initialValue, column, stopEditing, eGridCell } = props;

    const [inputEl, setInputEl] = useState<HTMLElement | null>(null);

    const [value, setValue] = useState<string>(`${initialValue || ""}`);
    const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);

    const errorMessages = column.isFormatValid
      ? column.isFormatValid(value)
      : null;

    /* Component Editor Lifecycle methods */
    useImperativeHandle(ref, () => {
      return {
        // the final value to send to the grid, on completion of editing
        getValue() {
          return errorMessages !== null ? initialValue : value;
        },

        isPopup() {
          return true;
        },

        // Gets called once before editing starts, to give editor a chance to
        // cancel the editing before it even starts.
        isCancelBeforeStart() {
          return false;
        },

        // Gets called once when editing is finished (eg if enter is pressed).
        // If you return true, then the result of the edit will be ignored.
        isCancelAfterEnd: () => {
          return errorMessages !== null;
        },
      };
    });

    useLayoutEffect(() => {
      if (eGridCell) {
        setAnchorEl(eGridCell);
      } else {
        setAnchorEl(null);
      }
    }, [eGridCell]);

    useLayoutEffect(() => {
      if (inputEl) {
        const input = inputEl.querySelector("input");
        if (input) {
          input.focus();
          input.setSelectionRange(0, input.value.length);
        }
      }
    }, [inputEl]);

    return (
      <Popover
        open
        className="custom-text-editor"
        anchorEl={anchorEl}
        onClose={() => {
          stopEditing();
        }}
      >
        <FormControl error={errorMessages !== null}>
          <Input
            style={{
              width: anchorEl ? `${anchorEl.clientWidth}px` : undefined,
            }}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.code === "Enter") {
                stopEditing();
              }
            }}
            ref={(element: HTMLElement) => {
              setInputEl(element);
            }}
          />
        </FormControl>
        {errorMessages !== null && (
          <div className="bottom-menu">
            <ul className="error-messages">
              {errorMessages.map((message, index) => (
                <li key={index}>{message}</li>
              ))}
            </ul>
            <Button
              variant="contained"
              color="primary"
              onClick={() => stopEditing()}
            >
              OK
            </Button>
          </div>
        )}
      </Popover>
    );
  }
);

export default CustomTextEditor;
