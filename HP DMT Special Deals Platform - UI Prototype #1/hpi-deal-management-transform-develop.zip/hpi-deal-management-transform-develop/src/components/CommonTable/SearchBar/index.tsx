import { TextField } from "@material-ui/core";
import React from "react";

export type SearchBarProps = {
  value: string;
  onChange: (newValue: string) => void;
};

const SearchBar: React.FunctionComponent<SearchBarProps> = ({
  value,
  onChange,
}) => {
  return (
    <TextField
      value={value}
      onChange={(event) => onChange(event.target.value)}
      label="Search"
      placeholder="Enter text to search for"
      variant="outlined"
    />
  );
};

export default SearchBar;
