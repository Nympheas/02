/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */
import React, { useCallback, useEffect, useRef, useState } from "react";
import * as _ from "lodash";
import ReactDOM from "react-dom";
import {
  BodyScrollEvent,
  CellClassParams,
  ColDef,
  Column,
  ColumnApi,
  ColumnResizedEvent,
  GridApi,
  GridReadyEvent,
  PaginationChangedEvent,
  RowClassParams,
  RowNode,
} from "ag-grid-community";
import { AgGridColumn, AgGridReact } from "ag-grid-react";
import {
  Button,
  ButtonGroup,
  Paper,
  PopoverPosition,
  TextField,
} from "@material-ui/core";
import { Add, Close, Remove } from "@material-ui/icons";

import "ag-grid-community/dist/styles/ag-grid.css";
import "ag-grid-community/dist/styles/ag-theme-alpine.css";

import HeaderContextualMenu from "./Menus/HeaderContextualMenu";
import CustomizeColumns from "./Modals/CustomizeColumns";
import CustomHeaderComponent from "./CustomHeaderComponent";
import FilterContextualMenu from "./Menus/FilterContextualMenu";
import { FilterDataGrid } from "./Modals/FilterDataGrid";
import WrapText from "./Modals/WrapText";
import {
  ContextualMenuItem,
  Filters,
  PartialSelectionRange,
  SelectionBorderSide,
  SelectionRange,
  TableActionMethods,
  TableClasses,
  TableColumn,
  TableColumnToggleableStatus,
  TableState,
} from "./types";
import {
  copyRowsFromSelectionRangesToClipboard,
  copyRowsToClipboard,
  getAllDisplayedColumns,
  getPastedRowData,
} from "./utils/clipboard";
import { getRangeSelectedClass, getCellUnderMouse } from "./utils/range";
import CellContextualMenu from "./Menus/CellContextualMenu";
import "./styles.scss";
import CustomDateCell from "./cells/CustomDateCell";
import CustomDropdownCell from "./cells/CustomDropdownCell";
import CustomTextEditor from "./editors/CustomTextEditor";
import CustomTextCell from "./cells/CustomTextCell";
import { filterRow } from "./utils/filters";

export type CommonTableProps = {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  rowData: any[];
  defaultColumns: TableColumn[];
  getRowProperties?: (
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    data: any,
    rowIndex: number
  ) => {
    bundleExpand?: JSX.Element | null;
  };
  contextualMenuOptions?: {
    getHeaderItems?: (
      columnId: string,
      actionMethods: TableActionMethods
    ) => ContextualMenuItem[];
    getCellItems?: (
      cell: { rowIndex: number; columnId: string },
      actionMethods: TableActionMethods
    ) => ContextualMenuItem[];
  };
  themeOptions?: {
    getRowClass?: (params: RowClassParams) => string | string[];
    getCellClass?: (
      params: RowClassParams & { colId: string; value: unknown }
    ) => string | string[];
  };
  disableFilters?: boolean;
  fixedColumns?: boolean;
};

const CommonTable: React.FunctionComponent<CommonTableProps> = ({
  defaultColumns,
  rowData,
  getRowProperties,
  contextualMenuOptions,
  themeOptions,
  disableFilters,
  fixedColumns,
}) => {
  const [contextualMenu, setContextualMenu] = useState<{
    position: PopoverPosition;
    type: "header" | "filter" | "cell" | "none";
    onClose?: () => void;
    columnKey?: string;
    cellContent?: string;
  } | null>(null);

  const ref = useRef<HTMLDivElement | null>(null);
  const columnsRef = useRef<TableColumn[]>(defaultColumns);
  const filtersRef = useRef<Filters[]>([]);
  const currentSelectionRef = useRef<PartialSelectionRange | null>(null);
  const currentSelectionStoppedRef = useRef<boolean>(true);
  const expandedRowsIndexesRef = useRef<number[]>([]);
  const updateRowsTimeoutIdRef = useRef<number>(-1);
  const pendentRowUpdatesRef = useRef<number[] | null>(null);
  const calculatingRowsRef = useRef<boolean>(false);
  const gridApiRef = useRef<GridApi | null>(null);

  const [cachedRows, setCachedRows] = useState<number[] | null>(null);
  const [rowsInView, setRowsInView] = useState<number[] | null>(null);
  const [cachedRowClasses, setCachedRowClasses] = useState<TableClasses | null>(
    null
  );
  const [columns, setColumns] = useState<TableColumn[]>(defaultColumns);
  const [selectionRanges, setSelectionRanges] = useState<SelectionRange[]>([]);
  const [toggleExpandedRowIndex, setToggleExpandedRowIndex] = useState<
    number | null
  >(null);
  const [expandedRowsIndexes, setExpandedRowsIndexes] = useState<number[]>([]);
  const [cellClasses, setCellClasses] = useState<{ [compId: string]: string }>(
    {}
  );
  const [changingClasses, setChangingClasses] = useState<boolean>(false);
  const [loadingState, setLoadingState] = useState<boolean>(false);
  const [gridColumnApi, setGridColumnApi] = useState<ColumnApi | null>(null);
  const [showCustomizeColumns, setShowCustomizeColumns] = useState<boolean>(
    false
  );
  const [showFilterDataGrid, setShowFilterDataGrid] = useState<boolean>(false);
  const [showWrapText, setShowWrapText] = useState<boolean>(false);
  const [searchText, setSearchText] = useState<string>("");
  const [showSearchPanel, setShowSearchPanel] = useState<boolean>(false);
  const [quickSearchText, setQuickSearchText] = useState<string>("");
  const [gridQuickSearchText, setGridQuickSearchText] = useState<string>("");

  const setCurrentSelection = (selection: PartialSelectionRange | null) => {
    currentSelectionRef.current = selection;
  };

  const gridApi = gridApiRef.current;

  const onGridReady = (params: GridReadyEvent) => {
    gridApiRef.current = params.api;
    setGridColumnApi(params.columnApi);
  };

  const bestFit = (thisColumn?: boolean) => {
    if (gridColumnApi) {
      let allColumns = gridColumnApi.getAllColumns();
      if (allColumns) {
        if (thisColumn && contextualMenu && contextualMenu.columnKey) {
          allColumns = allColumns.filter(
            (column) => column.getColId() === contextualMenu.columnKey
          );
        }
        gridColumnApi.autoSizeColumns(allColumns);
      }
    }
  };

  const clearRowClasses = useCallback((rowIndex?: number) => {
    if (ref.current) {
      // Clear classes of row & cells
      const clearRowsEls = Array.from(
        ref.current.querySelectorAll(
          `:not(.ag-hidden) > .ag-row${
            rowIndex !== undefined ? `[row-index="${rowIndex}"]` : ""
          }`
        )
      );
      clearRowsEls.forEach((rowEl) => {
        if (rowEl) {
          const rowBaseClasses = rowEl.className
            .split(" ")
            .filter((classToCheck) => classToCheck.startsWith("ag-"))
            .join(" ");
          // eslint-disable-next-line no-param-reassign
          rowEl.className = rowBaseClasses;
          const cellsEls = rowEl.querySelectorAll(".ag-cell");
          cellsEls.forEach((cellEl) => {
            const cellBaseClasses = cellEl.className
              .split(" ")
              .filter(
                (cellClassToCheck) =>
                  cellClassToCheck.startsWith("ag-") ||
                  cellClassToCheck === "selected-cell" ||
                  cellClassToCheck === "editable-cell" ||
                  cellClassToCheck === "disabled-cell"
              )
              .join(" ");
            // eslint-disable-next-line no-param-reassign
            cellEl.className = cellBaseClasses;
          });
        }
      });
    }
  }, []);

  const updateRowClasses = useCallback(
    (
      api: GridApi | null,
      columnApi: ColumnApi | null,
      rowIndexes?: number[]
    ) => {
      if (api && columnApi) {
        const newRowClasses: TableClasses = cachedRowClasses || {};
        const calculatedRows: number[] = [];
        api.getRenderedNodes().forEach((row) => {
          const params: RowClassParams | CellClassParams = {
            data: row.data,
            api,
            columnApi,
            node: row,
            rowIndex: row.rowIndex as number,
            $scope: {},
            context: {},
          };
          let recalculateRow = false;
          if (row.rowIndex !== null) {
            if (rowIndexes) {
              recalculateRow = rowIndexes.includes(row.rowIndex);
            } else {
              recalculateRow = cachedRows
                ? !cachedRows.includes(row.rowIndex as number)
                : true;
            }
          }
          if (recalculateRow) {
            if (themeOptions) {
              let classes: string | string[] = [];
              if (themeOptions.getRowClass) {
                classes = themeOptions.getRowClass(params);
              }
              // Add classes to object
              if (classes.length > 0) {
                if (Array.isArray(classes)) {
                  newRowClasses[row.rowIndex as number] = {
                    className: classes.join(" "),
                  };
                } else {
                  newRowClasses[row.rowIndex as number] = {
                    className: classes,
                  };
                }
              }
            }
            if (ref.current) {
              const rowsEls = ref.current.querySelectorAll(
                `:not(.ag-hidden) > .ag-row[row-index="${
                  row.rowIndex as number
                }"]`
              );
              // Clear cells heights
              rowsEls.forEach((rowEl) => {
                const cellsEls = rowEl.querySelectorAll(".ag-cell");
                cellsEls.forEach((cellEl) => {
                  // eslint-disable-next-line no-param-reassign
                  (cellEl as HTMLElement).style.height = "";
                });
              });
              if (getRowProperties) {
                const rowProperties = getRowProperties(
                  row.data,
                  row.rowIndex as number
                );
                // Handle bundle expand classes and cell heights
                if (rowProperties.bundleExpand) {
                  rowsEls.forEach((rowEl) => {
                    if (rowEl && row.rowIndex !== null) {
                      const bundleContentEl = rowEl.querySelector(
                        `.bundle-expand-content`
                      );
                      if (bundleContentEl) {
                        if (newRowClasses[row.rowIndex]) {
                          const rowClassName =
                            newRowClasses[row.rowIndex].className;
                          if (
                            rowClassName &&
                            !rowClassName.includes("bundle-expanded")
                          ) {
                            newRowClasses[row.rowIndex].className +=
                              " bundle-expanded";
                          }
                        } else {
                          newRowClasses[row.rowIndex] = {
                            className: "bundle-expanded",
                          };
                        }
                        if (row.rowHeight) {
                          const cellHeight =
                            row.rowHeight - bundleContentEl.clientHeight - 1;
                          const cellsEls = rowEl.querySelectorAll(".ag-cell");
                          cellsEls.forEach((cellEl) => {
                            // eslint-disable-next-line no-param-reassign
                            (cellEl as HTMLElement).style.height = `${cellHeight}px`;
                          });
                          (bundleContentEl as HTMLElement).style.marginTop = `${cellHeight}px`;
                        }
                      }
                    }
                  });
                }
              }
              // Get cell specific classes
              if (themeOptions && themeOptions.getCellClass) {
                rowsEls.forEach((rowEl) => {
                  const cellsEls = rowEl.querySelectorAll(".ag-cell");
                  const newCellsClasses: { [colId: string]: string } = {};
                  cellsEls.forEach((cellEl) => {
                    const colIdAttr = cellEl.attributes.getNamedItem("col-id");
                    if (colIdAttr && themeOptions.getCellClass) {
                      const colId = colIdAttr.value;
                      const newCellClasses = themeOptions.getCellClass({
                        ...params,
                        colId,
                        value: params.node.data[colId],
                      });
                      if (newCellClasses.length > 0) {
                        if (Array.isArray(newCellClasses)) {
                          newCellsClasses[colId] = newCellClasses.join(" ");
                        } else {
                          newCellsClasses[colId] = newCellClasses;
                        }
                      }
                    }
                  });
                  if (_.entries(newCellsClasses).length > 0) {
                    if (!newRowClasses[row.rowIndex as number]) {
                      newRowClasses[row.rowIndex as number] = {};
                    }
                    newRowClasses[
                      row.rowIndex as number
                    ].cellsClasses = newCellsClasses;
                  }
                });
              }
              calculatedRows.push(row.rowIndex as number);
              clearRowClasses(row.rowIndex as number);
            }
          }
        });
        // Set classes
        let finalRowClasses: TableClasses = newRowClasses;
        if (!cachedRowClasses || !_.isEqual(newRowClasses, cachedRowClasses)) {
          setCachedRowClasses(newRowClasses);
        } else {
          finalRowClasses = cachedRowClasses;
        }
        _.entries(finalRowClasses).forEach(
          (
            entry: [
              string,
              {
                className?: string;
                cellsClasses?: { [colId: string]: string };
              }
            ]
          ) => {
            const [rowIndex, rowClasses] = entry;
            if (ref.current) {
              const rowsEls = ref.current.querySelectorAll(
                `:not(.ag-hidden) > .ag-row[row-index="${rowIndex}"]`
              );
              rowsEls.forEach((rowEl) => {
                if (rowEl) {
                  if (
                    rowClasses.className &&
                    !rowEl.className.includes(rowClasses.className)
                  ) {
                    // eslint-disable-next-line no-param-reassign
                    rowEl.className += ` ${rowClasses.className}`;
                  }
                  if (rowClasses.cellsClasses) {
                    _.entries(rowClasses.cellsClasses).forEach(
                      (cellEntry: [string, string]) => {
                        const [colId, extraCellClasses] = cellEntry;
                        const cellEl = rowEl.querySelector(
                          `.ag-cell[col-id="${colId}"]`
                        );
                        if (
                          cellEl &&
                          extraCellClasses &&
                          !cellEl.className.includes(extraCellClasses)
                        ) {
                          // eslint-disable-next-line no-param-reassign
                          cellEl.className += ` ${extraCellClasses}`;
                        }
                      }
                    );
                  }
                }
              });
            }
          }
        );
        if (ref.current) {
          const newRowsInView: number[] = _.uniq(
            Array.from(
              ref.current.querySelectorAll(
                ".ag-center-cols-clipper:not(.ag-hidden) .ag-row"
              )
            )
              .map((rowEl) => {
                const rowIndexAttr = rowEl.attributes.getNamedItem("row-index");
                if (rowIndexAttr) {
                  return Number(rowIndexAttr.value);
                }
                return null;
              })
              .filter((rowIndex) => rowIndex !== null) as number[]
          );
          setRowsInView(newRowsInView);
        }
        setCachedRows(
          cachedRows ? _.union(cachedRows, calculatedRows) : calculatedRows
        );
      }
    },
    [
      themeOptions,
      getRowProperties,
      cachedRows,
      cachedRowClasses,
      clearRowClasses,
    ]
  );

  const handleExpandToggle = useCallback(
    (rowNode: RowNode, event: MouseEvent) => {
      event.preventDefault();
      event.stopPropagation();
      if (rowNode.rowIndex !== null && gridApi) {
        setToggleExpandedRowIndex(rowNode.rowIndex);
      }
    },
    [gridApi]
  );

  const calculateNewRowHeights = useCallback(
    (rowIndexes?: number[]) => {
      if (gridApi && ref.current) {
        gridApi.getRenderedNodes().forEach((rowNode) => {
          if (
            rowNode.rowIndex !== null &&
            (rowIndexes
              ? rowIndexes.includes(rowNode.rowIndex as number)
              : true)
          ) {
            let maxHeight = 41;
            let bundleHeight = 0;
            const rowsEls = (ref.current as HTMLDivElement).querySelectorAll(
              `:not(.ag-hidden) > .ag-row[row-index="${rowNode.rowIndex}"]`
            );
            rowsEls.forEach((rowEl) => {
              if (rowEl && rowNode.rowIndex !== null) {
                const cellsWithWrap = Array.from(
                  rowEl.querySelectorAll(".ag-cell.ag-cell-wrap-text")
                );
                cellsWithWrap.forEach((cell) => {
                  const container = cell.querySelector(".ag-react-container");
                  if (container && container.clientHeight > maxHeight) {
                    maxHeight = container.clientHeight;
                  }
                });
                // Bundle Expand
                if (getRowProperties) {
                  const rowProperties = getRowProperties(
                    rowNode.data,
                    rowNode.rowIndex
                  );
                  if (rowProperties.bundleExpand) {
                    const selectedCellEl = rowEl.querySelector(
                      ".ag-cell.selected-cell"
                    );
                    const bundleExpandButtonEl = rowEl.querySelector(
                      ".bundle-expand-button"
                    );
                    const bundleExpandEl = rowEl.querySelector(
                      ".bundle-expand-content"
                    );
                    if (selectedCellEl && !bundleExpandButtonEl) {
                      const newEl = document.createElement("div");
                      newEl.className = "bundle-expand-button";
                      newEl.onclick = (event) =>
                        handleExpandToggle(rowNode, event);

                      const expandEl = document.createElement("div");
                      expandEl.className = "expand-icon";

                      const closeExpandEl = document.createElement("div");
                      closeExpandEl.className = "close-expand-icon";

                      ReactDOM.render(<Add color="primary" />, expandEl);
                      ReactDOM.render(
                        <Remove color="primary" />,
                        closeExpandEl
                      );
                      newEl.appendChild(expandEl);
                      newEl.appendChild(closeExpandEl);
                      selectedCellEl.appendChild(newEl);
                    }
                    if (
                      expandedRowsIndexesRef.current.includes(rowNode.rowIndex)
                    ) {
                      if (!bundleExpandEl) {
                        if (rowEl.closest(".ag-center-cols-clipper")) {
                          const newEl = document.createElement("div");
                          newEl.className = "bundle-expand-content";
                          ReactDOM.render(rowProperties.bundleExpand, newEl);
                          rowEl.appendChild(newEl);
                          bundleHeight = newEl.clientHeight;
                        }
                      } else {
                        bundleHeight = bundleExpandEl.clientHeight;
                        // Make sure that bundle is last element in the row
                        if (rowEl.lastElementChild !== bundleExpandEl) {
                          rowEl.removeChild(bundleExpandEl);
                          rowEl.appendChild(bundleExpandEl);
                        }
                      }
                    } else if (bundleExpandEl) {
                      bundleExpandEl.remove();
                    }
                  }
                }
                rowNode.setRowHeight(maxHeight + bundleHeight);
              }
            });
          }
        });
        if (gridColumnApi) {
          updateRowClasses(gridApi, gridColumnApi, rowIndexes);
          gridApi.onRowHeightChanged();
        }
      }
    },
    [
      getRowProperties,
      gridApi,
      gridColumnApi,
      updateRowClasses,
      handleExpandToggle,
    ]
  );

  const isEditing = useCallback(() => {
    const editingModals =
      document.querySelector(".MuiDialog-root.custom-date-picker") ||
      document.querySelector(".MuiPopover-root.custom-dropdown-menu") ||
      document.querySelector(".MuiPopover-root.custom-text-editor");
    let tableActions = false;
    if (ref.current) {
      tableActions = !!ref.current.querySelector(
        ".ag-header-cell.ag-column-resizing"
      );
    }
    return !!(editingModals || tableActions);
  }, []);

  const queueRowUpdates = useCallback(
    (rowIndexes?: number[]) => {
      if (calculatingRowsRef.current && updateRowsTimeoutIdRef.current === -1) {
        calculatingRowsRef.current = false;
      }
      if (isEditing()) {
        return;
      }
      if (calculatingRowsRef.current) {
        if (rowIndexes) {
          pendentRowUpdatesRef.current = rowIndexes.slice();
        }
        return;
      }
      if (updateRowsTimeoutIdRef.current !== -1) {
        window.clearTimeout(updateRowsTimeoutIdRef.current);
      }
      calculatingRowsRef.current = true;
      updateRowsTimeoutIdRef.current = window.setTimeout(() => {
        if (!isEditing()) {
          calculateNewRowHeights(rowIndexes);
        }
        updateRowsTimeoutIdRef.current = -1;
        calculatingRowsRef.current = false;
        if (pendentRowUpdatesRef.current) {
          calculatingRowsRef.current = true;
          queueRowUpdates(pendentRowUpdatesRef.current.slice());
          pendentRowUpdatesRef.current = null;
        }
      }, 50);
    },
    [calculateNewRowHeights, isEditing]
  );

  useEffect(() => {
    if (toggleExpandedRowIndex !== null) {
      const newIndexes = expandedRowsIndexes.slice();
      if (!newIndexes.includes(toggleExpandedRowIndex)) {
        newIndexes.push(toggleExpandedRowIndex);
        if (ref.current) {
          const rowEl = ref.current.querySelector(
            `:not(.ag-hidden) > .ag-row[row-index="${toggleExpandedRowIndex}"]`
          );
          if (rowEl && !rowEl.classList.contains("bundle-expanded")) {
            const newRowClasses: TableClasses = _.cloneDeep(
              cachedRowClasses || {}
            );
            if (!newRowClasses[toggleExpandedRowIndex]) {
              newRowClasses[toggleExpandedRowIndex] = {
                className: "bundle-expanded",
              };
            } else if (newRowClasses[toggleExpandedRowIndex].className) {
              if (
                !(newRowClasses[toggleExpandedRowIndex]
                  .className as string).includes("bundle-expanded")
              ) {
                newRowClasses[toggleExpandedRowIndex].className +=
                  "bundle-expanded";
              }
            } else {
              newRowClasses[toggleExpandedRowIndex].className =
                "bundle-expanded";
            }
            newRowClasses[toggleExpandedRowIndex] = {
              className: "bundle-expanded",
            };
            if (cachedRowClasses && cachedRowClasses[toggleExpandedRowIndex]) {
              cachedRowClasses[toggleExpandedRowIndex].className = `${
                cachedRowClasses[toggleExpandedRowIndex].className as string
              } bundle-expanded`;
            }
            rowEl.classList.add("bundle-expanded");
          }
        }
      } else {
        newIndexes.splice(newIndexes.indexOf(toggleExpandedRowIndex), 1);
        if (ref.current) {
          const rowEl = ref.current.querySelector(
            `:not(.ag-hidden) > .ag-row[row-index="${toggleExpandedRowIndex}"]`
          );
          if (rowEl && rowEl.classList.contains("bundle-expanded")) {
            if (
              cachedRowClasses &&
              cachedRowClasses[toggleExpandedRowIndex] &&
              cachedRowClasses[toggleExpandedRowIndex].className &&
              (cachedRowClasses[toggleExpandedRowIndex]
                .className as string).includes("bundle-expanded")
            ) {
              const newCachedRowClasses = _.cloneDeep(cachedRowClasses);
              newCachedRowClasses[
                toggleExpandedRowIndex
              ].className = (cachedRowClasses[toggleExpandedRowIndex]
                .className as string).replace("bundle-expanded", "");
              setCachedRowClasses(newCachedRowClasses);
            }
            rowEl.classList.remove("bundle-expanded");
          }
        }
      }
      setExpandedRowsIndexes(newIndexes);
      setToggleExpandedRowIndex(null);
    }
  }, [
    toggleExpandedRowIndex,
    expandedRowsIndexes,
    cachedRowClasses,
    cachedRows,
  ]);

  useEffect(() => {
    const newExpandedRows = !_.isEqual(
      expandedRowsIndexes,
      expandedRowsIndexesRef.current
    );
    if (gridApi && gridColumnApi && newExpandedRows) {
      if (cachedRows) {
        // Remove cached row
        setCachedRows(
          cachedRows.filter(
            (rowIndex) => !expandedRowsIndexes.includes(rowIndex)
          )
        );
      }
      let expandedRowIndex: number[] = _.difference(
        expandedRowsIndexes,
        expandedRowsIndexesRef.current
      );
      if (expandedRowIndex.length === 0) {
        expandedRowIndex = _.difference(
          expandedRowsIndexesRef.current,
          expandedRowsIndexes
        );
      }
      expandedRowsIndexesRef.current = expandedRowsIndexes.slice();
      if (expandedRowIndex.length === 1) {
        queueRowUpdates(expandedRowIndex);
      }
    }
  }, [
    expandedRowsIndexes,
    gridApi,
    gridColumnApi,
    cachedRows,
    queueRowUpdates,
  ]);

  const wrapText = () => {
    setContextualMenu(null);
    setShowWrapText(true);
    if (gridApi && gridColumnApi) {
      queueRowUpdates();
    }
  };

  const unfreezeColumns = (allColumns: Column[]) => {
    if (gridColumnApi) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      gridColumnApi.setColumnsPinned(allColumns, false as any);
    }
  };

  const freezeColumns = (frozenColumns: number | null) => {
    if (gridColumnApi) {
      const allColumns = getAllDisplayedColumns(gridColumnApi, true);
      if (allColumns) {
        if (frozenColumns !== null) {
          unfreezeColumns(allColumns);
          gridColumnApi.setColumnsPinned(
            allColumns.slice(0, frozenColumns),
            "left"
          );
        } else {
          unfreezeColumns(allColumns);
        }
      }
    }
  };

  const fillRangeSelection = useCallback(
    (range: SelectionRange) => {
      const { start, end } = range;
      if (gridApi) {
        const first = gridApi.getDisplayedRowAtIndex(start.rowIndex);
        if (first) {
          let rows = gridApi.getRenderedNodes();
          if (start.rowIndex > end.rowIndex) {
            rows = rows.slice(end.rowIndex, start.rowIndex);
          } else if (start.rowIndex < end.rowIndex) {
            rows = rows.slice(start.rowIndex, end.rowIndex + 1);
          } else {
            rows = [];
          }
          const column = columns.find((col) => col.key === start.colId);
          const columnToggleableFlagKey =
            column &&
            column.toggleableStatus &&
            column.toggleableStatus.statusToggledKey;
          rows.forEach((row) => {
            if (row.rowIndex !== start.rowIndex) {
              if (ref.current) {
                const newData = {
                  ...row.data,
                };
                const isCellDisabled = column
                  ? column.isCellEditingDisabled
                  : null;
                const editable = column ? column.editable !== false : true;
                const cellsEls = Array.from(
                  ref.current.querySelectorAll(
                    `:not(.ag-hidden) > .ag-row[row-index="${row.rowIndex}"] .ag-cell[col-id="${start.colId}"]:not(.disabled)`
                  )
                );
                cellsEls.forEach((cellEl) => {
                  // Only modify cell if it isn't disabled
                  if (
                    (!isCellDisabled ||
                      !isCellDisabled({
                        value: newData[start.colId],
                        data: newData,
                      })) &&
                    editable
                  ) {
                    newData[start.colId] = first.data[start.colId];
                    if (columnToggleableFlagKey) {
                      newData[columnToggleableFlagKey] =
                        first.data[columnToggleableFlagKey];
                    }
                    if (cellEl) {
                      const flagHasChanged = columnToggleableFlagKey
                        ? row.data[columnToggleableFlagKey] !==
                          newData[columnToggleableFlagKey]
                        : false;
                      if (!cellEl.classList.contains("edited")) {
                        if (
                          row.data[start.colId] !== newData[start.colId] ||
                          flagHasChanged
                        ) {
                          cellEl.classList.add("edited");
                        }
                      }
                      if (flagHasChanged) {
                        const input = cellEl.querySelector(
                          ".MuiCheckbox-root input"
                        ) as HTMLSpanElement;
                        input.click();
                      }
                      row.setData(newData);
                      gridApi.refreshCells();
                    }
                  }
                });
              }
            }
          });
          updateRowClasses(gridApi, gridColumnApi);
        }
      }
    },
    [gridApi, gridColumnApi, columns, updateRowClasses]
  );

  // Re-calculate cell classes after selection changes instead of in every re-render
  const updateSelectedCellsClasses = useCallback(
    (newSelectionRanges: SelectionRange[]) => {
      if (!gridApi || !gridColumnApi || !ref.current || changingClasses) {
        return;
      }
      setChangingClasses(true);
      const newClasses: { [compId: string]: string } = {};
      const renderedRows = Array.from(
        ref.current.querySelectorAll(":not(.ag-hidden) .ag-row")
      );
      renderedRows.forEach((row) => {
        const renderedCells = Array.from(
          row.querySelectorAll(":not(.ag-hidden) .ag-cell")
        );
        const rowIndexAttr = row.attributes.getNamedItem("row-index");
        if (rowIndexAttr) {
          const rowIndex = Number(rowIndexAttr.value);
          renderedCells.forEach((cellEl) => {
            const colIdAttr = cellEl.attributes.getNamedItem("col-id");
            const compIdAttr = cellEl.attributes.getNamedItem("comp-id");
            if (colIdAttr && compIdAttr) {
              const colId = colIdAttr.value;
              const compId = compIdAttr.value;
              let isSelected = false;
              const allColumns = gridColumnApi.getAllDisplayedColumns() || [];
              const allRows = gridApi.getRenderedNodes();
              const borderSides: SelectionBorderSide[] = [];
              // Loop through ranges and check if selected and which borders are needed
              const cellX = allColumns.findIndex(
                (col) => col.getColId() === colId
              );
              const cellRowNode = gridApi.getDisplayedRowAtIndex(rowIndex);
              const cellY = cellRowNode ? allRows.indexOf(cellRowNode) : -1;
              let temp = -1;
              newSelectionRanges.forEach((range) => {
                const { start, end } = range;
                let xStart = allColumns.findIndex(
                  (col) => col.getColId() === start.colId
                );
                let xEnd = allColumns.findIndex(
                  (col) => col.getColId() === end.colId
                );
                const startRowNode = gridApi.getDisplayedRowAtIndex(
                  start.rowIndex
                );
                const endRowNode = gridApi.getDisplayedRowAtIndex(end.rowIndex);
                let yStart = startRowNode ? allRows.indexOf(startRowNode) : 0;
                let yEnd = endRowNode
                  ? allRows.indexOf(endRowNode)
                  : allRows.length;
                if (xStart < xEnd) {
                  temp = xStart;
                  xStart = xEnd;
                  xEnd = temp;
                }
                if (yStart < yEnd) {
                  temp = yStart;
                  yStart = yEnd;
                  yEnd = temp;
                }
                if (xStart >= cellX && xEnd <= cellX) {
                  if (yStart >= cellY && yEnd <= cellY) {
                    isSelected = true;
                    if (xEnd === cellX) {
                      borderSides.push("left");
                    }
                    if (xStart === cellX) {
                      borderSides.push("right");
                    }
                    if (yEnd === cellY) {
                      borderSides.push("top");
                    }
                    if (yStart === cellY) {
                      borderSides.push("bottom");
                    }
                  }
                }
              });
              if (isSelected) {
                const borderClasses =
                  borderSides.length > 0
                    ? ` ${borderSides
                        .map((side) => getRangeSelectedClass(side))
                        .join(" ")}`
                    : "";
                newClasses[compId] = ` ag-cell-range-selected${borderClasses}`;
              }
            }
          });
        }
      });
      setCellClasses(newClasses);
      setChangingClasses(false);
    },
    [gridApi, gridColumnApi, changingClasses]
  );

  const onTableMouseMove: React.MouseEventHandler<HTMLDivElement> = useCallback(
    (moveEvent) => {
      if (!currentSelectionStoppedRef.current && currentSelectionRef.current) {
        const cellUnder = getCellUnderMouse(moveEvent);
        if (cellUnder) {
          const fillCondition =
            currentSelectionRef.current.selectionMode === "fill" &&
            cellUnder.colId === currentSelectionRef.current.start.colId;
          if (
            currentSelectionRef.current.selectionMode !== "fill" ||
            fillCondition
          ) {
            setCurrentSelection({
              ...currentSelectionRef.current,
              end: cellUnder,
            });
            updateSelectedCellsClasses([
              ...(currentSelectionRef.current.selectionMode === "ctrl"
                ? selectionRanges
                : []),
              { start: currentSelectionRef.current.start, end: cellUnder },
            ]);
          }
        }
      }
    },
    [currentSelectionStoppedRef, updateSelectedCellsClasses, selectionRanges]
  );

  const onTableMouseUp: React.MouseEventHandler<HTMLDivElement> = useCallback(() => {
    currentSelectionStoppedRef.current = true;
    if (currentSelectionRef.current) {
      const { selectionMode, start, end } = currentSelectionRef.current;
      const newRanges: SelectionRange[] =
        selectionMode === "ctrl" ? selectionRanges.slice() : [];
      if (end) {
        const range: SelectionRange = {
          start,
          end,
        };
        if (selectionMode === "fill") {
          fillRangeSelection(range);
        } else {
          newRanges.push(range);
        }
      }
      setCurrentSelection(null);
      setSelectionRanges(newRanges);
      updateSelectedCellsClasses(newRanges);
    }
  }, [selectionRanges, updateSelectedCellsClasses, fillRangeSelection]);

  const onCellMouseDown: React.MouseEventHandler<HTMLDivElement> = useCallback(
    (event) => {
      // Right click is handled separately
      if (event.button === 2) {
        return;
      }
      if (
        (event.target as HTMLDivElement).className.includes &&
        (event.target as HTMLDivElement).className.includes("fill-handle")
      ) {
        const cell = getCellUnderMouse(event);
        if (cell) {
          currentSelectionStoppedRef.current = false;
          setCurrentSelection({
            start: cell,
            selectionMode: "fill",
          });
        }
        return;
      }
      if (event.type === "click" && currentSelectionRef.current) {
        const cellUnder = getCellUnderMouse(event);
        currentSelectionStoppedRef.current = true;
        if (cellUnder) {
          setCurrentSelection({
            ...currentSelectionRef.current,
            end: cellUnder,
          });
        }
        return;
      }
      if (gridApi) {
        const editingCells = gridApi.getEditingCells();
        if (editingCells && editingCells.length > 0) {
          return;
        }
      }
      if (currentSelectionRef.current || !currentSelectionStoppedRef.current) {
        return;
      }
      if (!event.ctrlKey && !event.metaKey) {
        setCurrentSelection(null);
        setSelectionRanges([]);
        setCellClasses({});
        return;
      }
      const cell = getCellUnderMouse(event);
      if (cell) {
        if (event.ctrlKey || event.metaKey) {
          setCurrentSelection({
            start: cell,
            selectionMode: "ctrl",
          });
          currentSelectionStoppedRef.current = false;
        }
      }
    },
    [gridApi]
  );

  useEffect(() => {
    if (ref.current) {
      // First, reset cell classes
      ref.current
        .querySelectorAll(":not(.ag-hidden) .ag-cell")
        .forEach((cellEl) => {
          if (
            cellEl.className.includes &&
            cellEl.className.includes("ag-cell-range")
          ) {
            const clearedClassName = cellEl.className
              .split(" ")
              .filter((className) => !className.includes("ag-cell-range"))
              .join(" ");
            // eslint-disable-next-line no-param-reassign
            cellEl.className = clearedClassName;
          }
        });

      _.entries(cellClasses).forEach((entry: [string, string]) => {
        const [compId, selectedClasses] = entry;
        const cellEl = (ref.current as HTMLDivElement).querySelector(
          `:not(.ag-hidden) .ag-cell[comp-id="${compId}"]`
        );
        if (
          cellEl &&
          cellEl.className.includes &&
          !cellEl.className.includes(selectedClasses)
        ) {
          cellEl.className += selectedClasses;
        }
      });
    }
  }, [cellClasses]);

  const resetTable = () => {
    if (gridApi && gridColumnApi) {
      // Close all contextual menus
      setContextualMenu(null);
      // Reset columns
      gridColumnApi.resetState();
      gridColumnApi.setColumnState([]);
      setColumns(defaultColumns);
      columnsRef.current = defaultColumns;
      // Reset search text
      setSearchText("");
      // Reset filters
      filtersRef.current = [];
      gridApi.onFilterChanged();
      gridApi.refreshHeader();
      window.localStorage.removeItem("table_state");

      queueRowUpdates();
    }
  };

  const saveTableState = useCallback(
    (newColumns?: TableColumn[]) => {
      if (loadingState) {
        return;
      }
      if (gridApi && gridColumnApi) {
        if (newColumns) {
          columnsRef.current = newColumns;
        }
        const tableState: TableState = {
          filters: filtersRef.current,
          columnState: gridColumnApi.getColumnState(),
          // Word wrap configuration
          columns: columnsRef.current.map(
            (column) =>
              ({
                key: column.key,
                label: column.label,
                wrapText: column.wrapText,
              } as TableColumn)
          ),
        };
        if (showSearchPanel) {
          tableState.searchPanel = {
            value: quickSearchText,
            filter: gridQuickSearchText,
          };
        }
        window.localStorage.setItem("table_state", JSON.stringify(tableState));

        setSelectionRanges([]);
        setCurrentSelection(null);
        currentSelectionStoppedRef.current = true;
        updateSelectedCellsClasses([]);
      }
    },
    [
      loadingState,
      gridApi,
      gridColumnApi,
      showSearchPanel,
      updateSelectedCellsClasses,
      quickSearchText,
      gridQuickSearchText,
    ]
  );

  const setFilters = (newFilters: Filters[]) => {
    filtersRef.current = newFilters;
    saveTableState();
  };

  useEffect(() => {
    setLoadingState(true);
    let intervalId = -1;
    const savedStateStr = window.localStorage.getItem("table_state");
    if (gridApi && gridColumnApi) {
      if (savedStateStr) {
        const savedState: TableState = JSON.parse(savedStateStr);
        const newColumns = savedState.columns.slice();
        // Copy helper functions from default columns
        newColumns.forEach((column, index) => {
          const defaultCol = defaultColumns.find(
            (defCol) => defCol.key === column.key
          );
          if (defaultCol) {
            newColumns[index] = {
              ...defaultCol,
              ...column,
            };
          }
        });
        columnsRef.current = newColumns;
        setColumns(newColumns);
        setFilters(savedState.filters);
        gridColumnApi.setColumnState(savedState.columnState);
        // Check if there's any column pinned, if so, pinned the selected column as well
        if (
          _.values(savedState.columnState).some(
            (column) => column.pinned !== null
          )
        ) {
          const selectedColumn = gridColumnApi
            .getAllDisplayedColumns()
            .find((col) => col.getColId() === "selected-column");
          if (selectedColumn) {
            selectedColumn.setPinned("left");
          }
        }
        // Check if search panel is opened
        if (savedState.searchPanel) {
          setShowSearchPanel(true);
          setQuickSearchText(savedState.searchPanel.value);
          gridApi.setQuickFilter(savedState.searchPanel.filter);
        }
        gridApi.onSortChanged();
        gridApi.onFilterChanged();
        gridApi.refreshHeader();
        gridApi.refreshClientSideRowModel();
      }
      queueRowUpdates();
      intervalId = window.setInterval(
        () =>
          queueRowUpdates(
            expandedRowsIndexesRef.current.length > 0
              ? expandedRowsIndexesRef.current
              : undefined
          ),
        1000
      );
    }
    setLoadingState(false);
    return () => {
      if (intervalId !== -1) {
        window.clearInterval(intervalId);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gridApi, gridColumnApi]);

  const getDisplayedColumns = () => {
    if (gridColumnApi) {
      const visibleColumns = gridColumnApi
        .getAllDisplayedColumns()
        .filter((col) => col.getColDef().headerName !== "Selected");
      return visibleColumns;
    }
    return [];
  };

  const onColumnResized = (params: ColumnResizedEvent) => {
    if (params.finished) {
      saveTableState();
    }
  };

  const onColumnVisible = () => {
    setCachedRowClasses(null);
    setCachedRows(null);
  };

  const getMaxContentLength = (key: string) => {
    return rowData.slice().reduce((prev, row) => {
      const content = _.get(row, key);
      const contentLength = content ? content.length : 0;
      if (contentLength > prev) {
        return contentLength;
      }
      return prev;
    }, 0);
  };

  const setGridQuickFilter = (text: string) => {
    if (gridApi) {
      gridApi.setQuickFilter(text);
      setGridQuickSearchText(text);
      saveTableState();
    }
  };

  const renderContextualMenu = () => {
    if (gridApi === null || contextualMenu === null) {
      return null;
    }
    const onCustomizeColumns = () => {
      setShowCustomizeColumns(true);
      setContextualMenu(null);
    };

    const onFilterDataGrid = () => {
      setShowFilterDataGrid(true);
      setContextualMenu(null);
    };

    const removeThisColumn = () => {
      if (gridColumnApi && contextualMenu && contextualMenu.columnKey) {
        gridColumnApi.setColumnVisible(contextualMenu.columnKey, false);
        setContextualMenu(null);
        saveTableState();
      }
    };

    const setSort = (order: string, shiftKey: boolean) => {
      if (gridApi && gridColumnApi) {
        if (!shiftKey && order !== "") {
          gridApi.setSortModel([]);
        }
        gridColumnApi.getColumn(contextualMenu.columnKey || "")?.setSort(order);
        gridApi.onSortChanged();
        queueRowUpdates();
      }
    };

    const toggleSearchPanel = () => {
      if (showSearchPanel) {
        setQuickSearchText("");
        if (gridApi) {
          setGridQuickFilter("");
        }
      }
      setShowSearchPanel(!showSearchPanel);
    };

    const handleExport = (onlySelected?: boolean) =>
      gridApi &&
      gridApi.exportDataAsCsv({
        columnKeys:
          gridApi
            .getColumnDefs()
            ?.filter(
              (column: ColDef) =>
                column.colId && column.headerName !== "Selected"
            )
            .map((column: ColDef) => column.colId as string) || [],
        onlySelected,
      });

    const selectedRowsItems: ContextualMenuItem[] = [
      {
        content: "Export selected rows",
        onClick: () => handleExport(true),
        disabled: gridApi.getSelectedRows().length === 0,
      },
    ];

    const actionMethods: TableActionMethods = {
      onCustomizeColumns,
      onFilterDataGrid,
      bestFit,
      wrapText,
      removeThisColumn,
      freezeColumns,
      setSort,
      toggleSearchPanel,
      isSearchPanelShown: showSearchPanel,
      resetTable,
      handleExport,
    };

    const focusedCell = gridApi.getFocusedCell();
    switch (contextualMenu.type) {
      case "filter":
        return (
          typeof contextualMenu.columnKey === "string" && (
            <FilterContextualMenu
              gridApi={gridApi}
              columnKey={contextualMenu.columnKey}
              tableColumn={columnsRef.current.find(
                (col) => col.key === contextualMenu.columnKey
              )}
              anchorPosition={contextualMenu.position}
              onFilterDataGrid={onFilterDataGrid}
              searchText={searchText}
              onSearchTextChange={(newSearchText) => {
                setSearchText(newSearchText);
                if (contextualMenu.columnKey) {
                  const newFilters: Filters[] = filtersRef.current.slice();
                  const filterIndex = newFilters.findIndex(
                    (filter) =>
                      filter.id === contextualMenu.columnKey &&
                      filter.value.operator === "contains"
                  );
                  if (filterIndex !== -1) {
                    if (newSearchText !== "") {
                      newFilters[filterIndex].value.condition = newSearchText;
                    } else {
                      newFilters.splice(filterIndex, 1);
                    }
                  } else {
                    newFilters.push({
                      id: contextualMenu.columnKey,
                      value: {
                        operator: "contains",
                        condition: newSearchText,
                      },
                    });
                  }
                  setFilters(newFilters);
                  gridApi.onFilterChanged();
                  gridApi.refreshHeader();
                }
              }}
              onClose={() => {
                if (contextualMenu.onClose) {
                  contextualMenu.onClose();
                }
                setContextualMenu(null);
                setSearchText("");
              }}
            />
          )
        );
      case "header":
        return (
          <HeaderContextualMenu
            gridApi={gridApi}
            contextualMenuAnchorPosition={contextualMenu.position}
            onCustomizeColumns={onCustomizeColumns}
            onFilterDataGrid={onFilterDataGrid}
            onClose={() => setContextualMenu(null)}
            bestFit={bestFit}
            wrapText={wrapText}
            removeThisColumn={removeThisColumn}
            freezeColumns={freezeColumns}
            setSort={setSort}
            toggleSearchPanel={toggleSearchPanel}
            isSearchPanelShown={showSearchPanel}
            resetTable={resetTable}
            handleExport={handleExport}
            disableFilters={disableFilters}
            customItems={[
              ...(contextualMenuOptions && contextualMenuOptions.getHeaderItems
                ? contextualMenuOptions.getHeaderItems(
                    contextualMenu.columnKey || "",
                    actionMethods
                  )
                : []),
            ]}
          />
        );
      case "cell":
        return (
          <CellContextualMenu
            gridApi={gridApi}
            anchorPosition={contextualMenu.position}
            onCopy={() => {
              if (contextualMenu && contextualMenu.cellContent !== undefined) {
                navigator.clipboard.writeText(contextualMenu.cellContent);
              }
              setContextualMenu(null);
            }}
            onCopyRow={() => {
              if (gridApi) {
                const cell = gridApi.getFocusedCell();
                if (cell) {
                  const { rowIndex } = cell;
                  const selectedRow = gridApi.getDisplayedRowAtIndex(rowIndex);
                  if (selectedRow) {
                    copyRowsToClipboard(
                      [selectedRow.data],
                      getDisplayedColumns()
                    );
                  }
                }
              }
              setContextualMenu(null);
            }}
            onCopyRange={(withHeaders) => {
              if (selectionRanges.length > 0 && gridApi && gridColumnApi) {
                copyRowsFromSelectionRangesToClipboard(
                  selectionRanges,
                  gridApi,
                  gridColumnApi,
                  withHeaders ? "readable" : undefined
                );
              }
            }}
            showRangesOptions={selectionRanges.length > 0}
            customItems={[
              ...(focusedCell &&
              contextualMenuOptions &&
              contextualMenuOptions.getCellItems
                ? contextualMenuOptions.getCellItems(
                    {
                      rowIndex: focusedCell.rowIndex,
                      columnId: focusedCell.column.getColId(),
                    },
                    actionMethods
                  )
                : []),
              ...selectedRowsItems,
            ]}
            onClose={() => setContextualMenu(null)}
          />
        );
      default:
        return null;
    }
  };

  const isExternalFilterPresent = useCallback(
    () => filtersRef.current.length > 0,
    []
  );

  const doesExternalFilterPass = useCallback(
    (node: RowNode) => filterRow(filtersRef.current, columnsRef.current, node),
    []
  );

  useEffect(() => {
    saveTableState();
  }, [showSearchPanel, saveTableState]);

  return (
    <div
      className={`common-table${showSearchPanel ? " search-panel-open" : ""}`}
      ref={ref}
      onKeyDown={(e) => {
        if (isEditing()) {
          return;
        }
        if (e.ctrlKey || e.metaKey) {
          if (e.code === "KeyC") {
            if (
              gridApi &&
              gridColumnApi &&
              gridApi.getEditingCells().length === 0
            ) {
              const selectedRows = gridApi.getSelectedRows();
              const focusedCell = gridApi.getFocusedCell();
              // First check for selected ranges, then for selected rows, and finally for focused cells
              if (selectionRanges.length > 0) {
                copyRowsFromSelectionRangesToClipboard(
                  selectionRanges,
                  gridApi,
                  gridColumnApi
                );
              } else if (selectedRows.length > 0) {
                copyRowsToClipboard(selectedRows, getDisplayedColumns());
              } else if (focusedCell) {
                const row = gridApi.getDisplayedRowAtIndex(
                  focusedCell.rowIndex
                );
                if (row) {
                  const cellContent = row.data[focusedCell.column.getColId()];
                  if (cellContent) {
                    navigator.clipboard.writeText(`${cellContent}`);
                  }
                }
              }
            }
          } else if (e.code === "KeyV") {
            if (gridApi && gridColumnApi) {
              const selection =
                selectionRanges.length > 0
                  ? selectionRanges
                  : gridApi.getFocusedCell();
              if (selection) {
                getPastedRowData(
                  gridColumnApi,
                  selection,
                  columns,
                  rowData
                ).then((newRowData) => {
                  gridApi.setRowData(newRowData);
                });
              }
            }
          }
        }
      }}
      onMouseMove={(event) => onTableMouseMove(event)}
      onMouseUp={(event) => onTableMouseUp(event)}
      onMouseUpCapture={(event) => onTableMouseUp(event)}
    >
      <div
        className="ag-theme-alpine"
        style={{ flexGrow: 1, width: "100%" }}
        onContextMenu={(e) => {
          const target = e.target as HTMLElement;
          if (target.closest) {
            const headerCell = target.closest(
              ".ag-header-cell:not(.selected-header)"
            );
            if (headerCell) {
              // Clicked header cell
              e.preventDefault();
              e.stopPropagation();
              const columnKey = (() => {
                if (gridColumnApi) {
                  const allColumns = gridColumnApi.getAllColumns();
                  if (allColumns) {
                    return allColumns
                      .find(
                        (col) =>
                          col.getColId() !== undefined &&
                          col.getColId() === headerCell.getAttribute("col-id")
                      )
                      ?.getColId();
                  }
                }
                return undefined;
              })();
              if (columnKey !== "0") {
                setContextualMenu({
                  position: {
                    top: e.clientY - 3,
                    left: e.clientX - 2,
                  },
                  type: "header",
                  columnKey,
                });
              }
            } else {
              const cell = target.closest(".ag-cell");
              if (cell) {
                // Clicked cell
                e.preventDefault();
                e.stopPropagation();
                if (gridApi) {
                  const rowEl = cell.parentElement;
                  const rowIndexAttr = rowEl
                    ? rowEl.attributes.getNamedItem("row-index")
                    : null;
                  const colIdAttr = cell.attributes.getNamedItem("col-id");
                  if (rowIndexAttr && colIdAttr) {
                    const colId = colIdAttr.value;
                    const rowIndex = rowIndexAttr.value;
                    if (colId !== "" && rowIndex !== "") {
                      gridApi.setFocusedCell(Number(rowIndex), colId);
                      setContextualMenu({
                        position: {
                          top: e.clientY - 3,
                          left: e.clientX - 2,
                        },
                        type: "cell",
                        cellContent: cell.textContent || "",
                      });
                    }
                  }
                }
              }
            }
          }
        }}
      >
        {showSearchPanel && (
          <Paper className="search-panel">
            <Close
              onClick={() => {
                setShowSearchPanel(false);
                setQuickSearchText("");
                if (gridApi) {
                  setGridQuickFilter("");
                }
              }}
            />{" "}
            <TextField
              value={quickSearchText}
              onChange={(event) => setQuickSearchText(event.target.value)}
              onKeyDown={(event) =>
                event.key === "Enter" &&
                gridApi &&
                setGridQuickFilter(quickSearchText)
              }
            />{" "}
            <ButtonGroup>
              <Button
                color="primary"
                onClick={() => {
                  if (gridApi) {
                    setGridQuickFilter(quickSearchText);
                  }
                }}
              >
                Find
              </Button>
              <Button
                color="secondary"
                onClick={() => {
                  if (gridApi) {
                    setGridQuickFilter("");
                  }
                  setQuickSearchText("");
                }}
                disabled={quickSearchText === ""}
              >
                Clear
              </Button>
            </ButtonGroup>
          </Paper>
        )}
        <AgGridReact
          onGridReady={(params) => onGridReady(params)}
          onColumnMoved={() => {
            saveTableState();
          }}
          onColumnResized={onColumnResized}
          onColumnVisible={onColumnVisible}
          onRowDataUpdated={() => saveTableState()}
          onSortChanged={() => {
            saveTableState();
            setExpandedRowsIndexes([]);
            expandedRowsIndexesRef.current = [];
            setCachedRowClasses(null);
            setCachedRows(null);
            clearRowClasses();
            queueRowUpdates();
          }}
          onColumnPinned={() => saveTableState()}
          onPaginationChanged={(event: PaginationChangedEvent) => {
            if (event.newPage) {
              setExpandedRowsIndexes([]);
              expandedRowsIndexesRef.current = [];
              setCachedRowClasses(null);
              setCachedRows(null);
              clearRowClasses();
            }
          }}
          onBodyScroll={(params: BodyScrollEvent) => {
            const newRowsInView = params.api
              .getRenderedNodes()
              .filter((row) => row.rowIndex !== null)
              .map((row) => row.rowIndex);

            if (rowsInView !== null && rowsInView !== newRowsInView) {
              const addedRows = _.difference(newRowsInView, rowsInView);
              if (addedRows.length > 0) {
                queueRowUpdates(addedRows as number[]);
              }
              updateSelectedCellsClasses(selectionRanges);
            }
          }}
          onCellValueChanged={(params) => {
            const cellsEls =
              ref.current &&
              ref.current.querySelectorAll(
                `:not(.ag-hidden) > .ag-row[row-index="${
                  params.rowIndex
                }"] > .ag-cell[col-id="${params.column.getColId()}"]`
              );
            if (cellsEls) {
              cellsEls.forEach((cellEl) => {
                if (cellEl) {
                  cellEl.classList.add("edited");
                }
              });
            }
            queueRowUpdates();
          }}
          rowData={rowData}
          rowBuffer={50}
          rowSelection="multiple"
          multiSortKey="shift"
          frameworkComponents={{
            agColumnHeader: CustomHeaderComponent,
            cellRenderer: CustomTextCell,
            dateCellRenderer: CustomDateCell,
            dropdownCellRenderer: CustomDropdownCell,
            customTextEditor: CustomTextEditor,
          }}
          defaultColDef={{
            resizable: !fixedColumns,
            filter: !disableFilters,
            suppressMovable: fixedColumns,
            editable: true,
            sortable: true,
            suppressMenu: true,
            suppressAutoSize: true,
            minWidth: 200,
            filterParams: { excelMode: "windows" },
            headerComponentParams: {
              onOpenFilters: disableFilters
                ? null
                : (
                    position: PopoverPosition,
                    columnKey: string,
                    api: GridApi,
                    onClose: () => void
                  ) => {
                    if (api) {
                      const containsFilter = filtersRef.current.find(
                        (filter) =>
                          filter.id === columnKey &&
                          filter.value.operator === "contains"
                      );
                      if (containsFilter && containsFilter.value.condition) {
                        setSearchText(containsFilter.value.condition);
                      }
                    }
                    setContextualMenu({
                      position,
                      type: "filter",
                      columnKey,
                      onClose,
                    });
                  },
              isFilterActive: (colKey: string) =>
                filtersRef.current.some((filter) => filter.id === colKey),
            },
          }}
          pagination
          groupSelectsChildren
          pivotPanelShow="always"
          isExternalFilterPresent={isExternalFilterPresent}
          doesExternalFilterPass={doesExternalFilterPass}
        >
          <AgGridColumn
            headerName="Selected"
            headerClass="selected-header"
            cellClass="selected-cell"
            colId="selected-column"
            lockVisible
            lockPinned
            checkboxSelection
            headerCheckboxSelection
            suppressMovable
            lockPosition
            suppressMenu
            suppressPaste
            editable={false}
            suppressFiltersToolPanel
            resizable={false}
            rowDrag={false}
            maxWidth={60}
          />
          {columns.map((col, index) => {
            const isDateCell = col.cellType === "date";
            const isDisabled = col.isCellEditingDisabled || (() => false);
            const isEditable =
              col.cellType !== "date" && col.editable !== false;
            let cellRenderer = "cellRenderer";
            let cellEditor: string | undefined;
            switch (col.cellType) {
              case "date":
                cellRenderer = "dateCellRenderer";
                break;
              case "dropdown":
                cellRenderer = "dropdownCellRenderer";
                break;
              default:
                cellEditor = "customTextEditor";
                break;
            }
            const interceptedCol = {
              ...col,
            };
            if (col.toggleableStatus) {
              const {
                onStatusToggled,
                statusToggledKey,
              } = col.toggleableStatus;
              // eslint-disable-next-line no-param-reassign
              (interceptedCol.toggleableStatus as TableColumnToggleableStatus).onStatusToggled = (
                newStatus,
                rowIndex,
                api,
                columnApi
              ) => {
                if (onStatusToggled) {
                  onStatusToggled(newStatus, rowIndex);
                }
                if (statusToggledKey) {
                  if (api && columnApi) {
                    const rowNode = api.getDisplayedRowAtIndex(rowIndex);
                    if (rowNode) {
                      const newData = {
                        ...rowNode.data,
                      };
                      newData[statusToggledKey] = newStatus;
                      rowNode.setData(newData);
                      api.refreshClientSideRowModel();
                      api.refreshInMemoryRowModel();
                    }
                    updateRowClasses(api, columnApi);
                  }
                }
              };
            }
            const cellRendererParams = {
              tableColumn: interceptedCol,
              onMouseDown: onCellMouseDown,
            };
            return (
              <AgGridColumn
                field={col.key}
                cellClass={(params) => {
                  const isCellDisabled = isDisabled(params);
                  return `${
                    (isEditable || isDateCell) && !isCellDisabled
                      ? "editable-cell"
                      : ""
                  }${isCellDisabled ? " disabled-cell" : ""}`;
                }}
                headerName={col.label}
                wrapText={col.wrapText}
                autoHeight={col.wrapText}
                // width={gridColumnApi?.getColumn(col.key)?.getActualWidth()}
                cellEditor={cellEditor}
                cellEditorParams={{
                  column: interceptedCol,
                }}
                cellRenderer={cellRenderer}
                cellRendererParams={cellRendererParams}
                pinnedRowCellRenderer={cellRenderer}
                pinnedRowCellRendererParams={cellRenderer}
                editable={(params) => isEditable && !isDisabled(params)}
                key={index}
              />
            );
          })}
        </AgGridReact>
      </div>
      {renderContextualMenu()}
      {showCustomizeColumns && (
        <CustomizeColumns
          isOpen
          columns={gridColumnApi?.getAllColumns() || []}
          onClose={() => setShowCustomizeColumns(false)}
          setHiddenColumns={(hiddenColumns) => {
            if (gridColumnApi) {
              const allColumns = gridColumnApi.getAllColumns();
              if (allColumns) {
                gridColumnApi.setColumnsVisible(allColumns, true);
              }
              gridColumnApi.setColumnsVisible(hiddenColumns, false);
            }
          }}
        />
      )}
      {showFilterDataGrid && (
        <FilterDataGrid
          onClose={() => setShowFilterDataGrid(false)}
          filters={filtersRef.current}
          tableColumns={columnsRef.current}
          columns={
            gridColumnApi
              ?.getAllColumns()
              ?.filter(
                (column) => column.getColDef().headerName !== "Selected"
              ) || []
          }
          setAllFilters={(newFilters) => {
            if (gridApi) {
              setFilters(newFilters);
              gridApi.onFilterChanged();
              gridApi.refreshHeader();
              queueRowUpdates();
            }
          }}
        />
      )}
      {showWrapText && (
        <WrapText
          columns={columns
            .slice()
            .sort((a, b) =>
              getMaxContentLength(a.key) < getMaxContentLength(b.key) ? 1 : -1
            )}
          onWrapChanged={(newColumnsChecked) => {
            const newColumns: TableColumn[] = columns.map((column) => ({
              ...column,
              wrapText: newColumnsChecked.includes(column.key),
            }));
            setColumns(newColumns);
            saveTableState(newColumns);
            setShowWrapText(false);

            queueRowUpdates();
          }}
          onClose={() => setShowWrapText(false)}
        />
      )}
    </div>
  );
};

export default CommonTable;
