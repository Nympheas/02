# HP DMT Special Deals Platform Table Component

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the production mode (serves the latest built version at `./build`, see `npm run build`).
Open [http://localhost:5000](http://localhost:5000) to view it in the browser.

### `npm run dev`

Runs the app in the development mode.
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.

### `npm test`

Launches the test runner in the interactive watch mode.

### `npm run build`

Builds the app for production to the `build` folder.

### `npm run deploy:heroku`

Make sure that you have installed and logged into the Heroku CLI.
The command expects an app called `hp-dmt` to deploy to.

Clears the latest build, builds the app for production, and deploys it to Heroku.


### `npm run lint`

Lints all the files of the project

### `npm run lint:fix`

Lints all the files of the project and fixes the issues that can be solved automatically

### `npm run format`

Formats the all the files of the project using Prettier
